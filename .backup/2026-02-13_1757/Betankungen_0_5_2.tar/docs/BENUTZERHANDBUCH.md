# Benutzerhandbuch Betankungen
**Stand:** 2026-02-12

CLI-Anwendung zum Erfassen und Auswerten von Tankvorgaengen (SQLite, lokal).

---

**Kurzueberblick**
- Erfassen von Tankstellen und Betankungen (interaktiv).
- Listen mit Standard- und Detailansicht.
- Volltank-Zyklus-Statistiken (Text und JSON).
- XDG-konforme Speicherung von Konfiguration und Datenbank.

**Start und Hilfe**
- Hilfe: `Betankungen --help`
- Version: `Betankungen --version`

**Datenbank und Konfiguration**
- Standard-DB: `~/.local/share/Betankungen/betankungen.db`
- Demo-DB: `~/.local/share/Betankungen/betankungen_demo.db`
- Config-Datei: `~/.config/Betankungen/config.ini`
- Erststart: Es wird nach dem DB-Pfad gefragt (Enter = Standard).
- Pfad dauerhaft setzen: `Betankungen --db-set /pfad/zur/db.sqlite`
- Pfad nur fuer diesen Lauf: `Betankungen --db /pfad/zur/db.sqlite <command>`
- Config anzeigen: `Betankungen --show-config`
- Config loeschen: `Betankungen --reset-config`

**Demo-Datenbank**
- Demo-DB erstellen/aktualisieren:  
  `Betankungen --seed [--stations N] [--fuelups N] [--seed-value N] [--force]`
- Demo-DB fuer einen Lauf nutzen:  
  `Betankungen --demo <command>`
- Hinweis: `--seed` ist exklusiv und darf nicht mit `--db`, `--db-set` oder anderen Kommandos kombiniert werden.

**Tankstellen verwalten**
Kommandos:
- `Betankungen --add stations`
- `Betankungen --list stations`
- `Betankungen --list stations --detail`
- `Betankungen --edit stations`
- `Betankungen --delete stations`

Eingabe bei `--add stations`:
- Pflichtfelder: Brand, Street, HouseNo, Plz, City
- Optional: Phone, Owner

**Betankungen erfassen**
Kommandos:
- `Betankungen --add fuelups`
- `Betankungen --list fuelups`
- `Betankungen --list fuelups --detail`

Eingabe bei `--add fuelups`:
- Auswahl der Tankstelle (Liste mit IDs)
- Datum+Uhrzeit: `YYYY-MM-DD HH:MM:SS`
- Kilometerstand (km)
- Gesamtpreis (EUR, z.B. `50,01`)
- Getankte Menge (Liter, z.B. `28,76`)
- Preis pro Liter (EUR/L, z.B. `1,739`)
- Vollgetankt? (y/n)
- Optional: Spritart, Bezahlart, Zapfsaeule, Notiz

**Statistiken: Volltank-Zyklen**
- Textausgabe: `Betankungen --stats fuelups`
- Dashboard-Ausgabe (exklusiv): `Betankungen --stats fuelups --dashboard` (kein Mix mit `--json`/`--csv`)
- JSON-Ausgabe (kompakt): `Betankungen --stats fuelups --json`
- JSON-Ausgabe (pretty): `Betankungen --stats fuelups --json --pretty` (nur mit `--json`)
- CSV-Ausgabe (exklusiv): `Betankungen --stats fuelups --csv` (mit `--monthly` moeglich, kein Mix mit `--json`)
- Monatsausgabe (Text, Monats-Tabelle): `Betankungen --stats fuelups --monthly`
- Monatsausgabe (JSON): `Betankungen --stats fuelups --json --monthly`
- Zeitraum-Filter:  
  `Betankungen --stats fuelups --from YYYY-MM[-DD] --to YYYY-MM[-DD]`
- Regeln: `--from` ist inklusiv, `--to` ist exklusiv. Zyklen zaehlen nur, wenn Start- und End-Volltank im Zeitraum liegen. Bei nur `--from` oder nur `--to` werden die fehlenden Grenzen datengetrieben gesetzt.

**Schnellbeispiele (Dashboard)**
- `Betankungen --stats fuelups --dashboard`
- `Betankungen --stats fuelups --dashboard --from 2025-01 --to 2025-03`
- `Betankungen --stats fuelups --dashboard --monthly`

**Diagnose und Ausgabe**
- Debug-Tabelle: `--debug`
- Trace-Logs: `--trace`
- Ruhiger Modus (unterdrueckt normale Ausgaben): `--quiet`

**Typischer Ablauf**
1. `Betankungen --db-set /pfad/zur/db.sqlite` (optional, wenn Standardpfad nicht gewuenscht)
2. `Betankungen --add stations`
3. `Betankungen --add fuelups`
4. `Betankungen --list fuelups --detail`
5. `Betankungen --stats fuelups --from 2025-01 --to 2025-03`
