# CHANGELOG
**Stand:** 2026-02-12

Alle wichtigen Änderungen an diesem Projekt werden hier dokumentiert.

## [Unreleased]
### Zielversion
0.5.3
Ziel: Offen.

### Changed (Codex)
- Docs: STATUS auf konsistenten 0.5.2-Abschluss gebracht und Kurzfazit auf "0.5.2 freigegeben" aktualisiert. (2026-02-12)
- Docs: ARCHITECTURE auf Stand 0.5.2 aktualisiert (Stand-Datum, Funktionsumfang, abgeschlossener 0.5.2-Abschnitt). (2026-02-12)
- Docs: README/BENUTZERHANDBUCH um konkrete Dashboard-Schnellbeispiele ergaenzt. (2026-02-12)
- Docs: DESIGN_PRINCIPLES-Nummerierung konsolidiert (doppelte "9" entfernt) und Stand-Datum aktualisiert. (2026-02-12)

## 0.5.2 – 2026-02-12

### Added
Ziel von 0.5.2:
- Ein kompaktes, scanbares Konsolen-Dashboard fuer `--stats fuelups`, das sich visuell klar von der Tabellen-Ausgabe unterscheidet und langfristig als Grundlage fuer ein einheitliches Unicode-Box-Design dient.
- Kein CLI-Umbau.
- Kein neues Subcommand.
- Keine GUI.
- Dashboard ist ein alternativer Renderer innerhalb des bestehenden Stats-Systems.

### Changed (User-Edits)
- u_fmt: Dashboard-Bar (Kosten-Balken) inkl. Farblogik, ANSI-sichere Box-Zeilen und Konfig-Variablen ergaenzt; `FmtScaledInt` ins Interface gehoben. (2026-02-11)
- u_stats: Dashboard-Renderer (`RenderFuelupDashboardText`) und `ShowFuelupDashboard`-Overloads ergaenzt (API). (2026-02-11)

### Changed (Codex)
- u_fmt: Dashboard-Farblogik um `TDashColorMode` erweitert (static/relative); `ResolveDashColor` nutzt nun `Cents` + `MaxCents`. (2026-02-12)
- Docs: README um Hinweis auf umschaltbare Dashboard-Farblogik (Cent vs. Promille) ergaenzt. (2026-02-12)
- u_fmt: `AnsiVisibleLen` auf UTF-8-sichtbare Laenge (nach `StripAnsi`) umgestellt; Padding bei Mehrbyte-Zeichen stabilisiert. (2026-02-12)
- CLI: Stats-Dispatch strukturell refaktoriert (`--dashboard`-Pfad im finalen Else-Block), Verhalten unveraendert. (2026-02-12)
- CLI: `--dashboard` fuer `--stats fuelups` ergaenzt (Parsing, Usage, Validierung, Dispatch zu `ShowFuelupDashboard`). (2026-02-12)
- Docs: README/BENUTZERHANDBUCH/STATUS auf `--dashboard`-Flag und CLI-Status aktualisiert. (2026-02-12)
- u_table: UTF-8-sichtbare Breite/Cut fuer stabiles Tabellenlayout mit Mehrbyte-Zeichen ergaenzt. (2026-02-12)
- Docs: README um UTF-8-Hinweis bei `u_table.pas` ergaenzt. (2026-02-12)
- Meta: `kpr.sh` nutzt versionierten Archivnamen `Betankungen_<version>.tar`. (2026-02-11)
- Docs: README/DESIGN_PRINCIPLES auf versionierten `kpr.sh`-Archivnamen aktualisiert. (2026-02-11)
- CLI: Temporaere Dashboard-Testverdrahtung in `--stats fuelups` wieder entfernt. (2026-02-11)
- Docs: STATUS-Hinweis zur temporaeren CLI-Verdrahtung entfernt. (2026-02-11)
- Docs: README/STATUS auf Dashboard-API und Box-Engine-Erweiterungen aktualisiert. (2026-02-11)
- u_stats: Header-Doku um Dashboard-Ausgabe ergaenzt. (2026-02-11)
- u_fmt: Unicode-Box-Engine (BoxTop/BoxSep/BoxBottom/BoxLine/BoxKV) ergaenzt. (2026-02-11)
- Docs: README um Unicode-Box-Engine in `u_fmt` ergaenzt. (2026-02-11)
- Docs: Zielbeschreibung 0.5.2 in STATUS/CHANGELOG ergaenzt. (2026-02-11)
- Docs: Roadmap 0.5.2 um Status-Dashboard ergaenzt. (2026-02-11)
- Docs: Release-Prep 0.5.1 (CHANGELOG/STATUS/ARCHITECTURE) konsolidiert. (2026-02-11)
- Docs: DESIGN_PRINCIPLES Stand + Output-Formate-Policy ergaenzt. (2026-02-11)
- Meta: `kpr.sh` als Release-Archiv + Log-Skript im Projektroot ergaenzt. (2026-02-11)
- Meta: `kpr.sh` APP_VERSION-Auslese im Log korrigiert. (2026-02-11)
- Meta: `kpr.sh` schreibt Release-Summary ins Log und gibt sie auf STDOUT aus. (2026-02-11)
- Meta: `kpr.sh` normalisiert `release_log.json` auf kompakte JSON-Form. (2026-02-11)
- Meta: `kpr.sh` Log-Append robust gegen ungueltige JSONs (Neuschreiben via Python). (2026-02-11)

## 0.5.1 – 2026-02-11
### Decisions
- Offene Grenzen bei Filtern datengetrieben festgelegt: nur `--from` => `to = MAX(fueled_at)`, nur `--to` => `from = MIN(fueled_at)` (kein "heute"). (2026-02-09)
- Zyklusregel am Rand festgelegt: Zyklus zählt nur, wenn Start- und End-Volltank im Zeitraum liegen (vollständig im Zeitraum). (2026-02-09)
- JSON-avg festgelegt: `avg_l_per_100km` als scaled Integer (z. B. `avg_l_per_100km_x100`), keine Strings. (2026-02-09)

### Changed (User-Edits)
- CLI: `--csv`/`--pretty` Flags inkl. Validierung/Usage/Dispatch fuer `--stats fuelups` ergaenzt. (2026-02-11)
- CLI: `--from`/`--to` Parsing (YYYY-MM oder YYYY-MM-DD) mit Normalisierung auf `PeriodFromIso`/`PeriodToExclIso`. (2026-02-09)
- CLI: Zentrale Validierung von `--from/--to` (nur mit `--stats fuelups`, from < to, Open-Ended-Reset). (2026-02-09)
- CLI: `--monthly` Flag fuer `--stats fuelups` ergaenzt (Parsing, Validierung, Usage, Dispatch). (2026-02-10)
- u_fmt: CSV-Helper `CsvTokenStrict`/`CsvJoin`/`CsvJoinInt64` ergänzt. (2026-02-10)
- Meta: Projektweite Codex-Regeln in `AGENTS.md` definiert. (2026-02-10)
- Meta: Definition „größere Änderungen“ und Prioritäten in `AGENTS.md` ergänzt. (2026-02-10)
- Meta: Präzisierungen zu Header-Datum, vorhandenen Headern und Doku-Priorität in `AGENTS.md`. (2026-02-10)
- Meta: CHANGELOG-Pflege folgt dem bestehenden Datei-Stil/Abschnitt. (2026-02-10)
- Meta: CHANGELOG-Kennzeichnung User vs. Codex in `AGENTS.md` festgelegt. (2026-02-10)
- Meta: CHANGELOG-Einträge immer unter `[Unreleased]` in bestehenden Unterabschnitten. (2026-02-10)
- Meta: CHANGELOG-Beispielformat in `AGENTS.md` ergänzt. (2026-02-10)
- Meta: CHANGELOG-Beispiel explizit unter „Changed (Codex)“ verankert. (2026-02-10)
- Meta: CHANGELOG-Beispiel auch fuer „Changed (User-Edits)“ ergänzt. (2026-02-10)
- Meta: CHANGELOG-Beispiele in `AGENTS.md` konkretisiert. (2026-02-10)
- Stats: Helper `ResolvePeriodBounds` und `ApplyPeriodWhere` in `u_stats.pas` eingefuegt. (2026-02-09)
- Stats: `ShowFuelupStats` nutzt Period-Resolve + optionales WHERE in Kopf- und Zyklus-Query. (2026-02-09)
- Stats: `ShowFuelupStatsJson` nutzt Period-Resolve + optionales WHERE und gibt `avg_l_per_100km_x100` aus. (2026-02-09)
- Docs: README-Abschnitt zu `u_stats.pas` auf `avg_l_per_100km_x100` aktualisiert. (2026-02-09)
- Orchestrator: `--stats fuelups` Dispatch reicht Period-Parameter an `u_stats` durch (Text/JSON). (2026-02-09)
- Docs: JSON-Beispielausgabe fuer `--stats fuelups --json` in README ergaenzt. (2026-02-09)

### Changed (Codex)
- Docs: BENUTZERHANDBUCH/README/STATUS/ARCHITECTURE auf `--csv`/`--pretty` aktualisiert. (2026-02-11)
- Docs: 0.5.1 CLI-Flag-Skizze (csv/pretty + Validierung/Dispatch) in STATUS ergänzt. (2026-02-11)
- Docs: ARCHITECTURE CSV-Helper Hinweis an Stats-CSV-Realitaet angepasst. (2026-02-11)
- Stats: `ShowFuelupStatsJson` nutzt Collector-Resultat konsistent via `R`. (2026-02-11)
- Stats: `ShowFuelupStatsCsv` nutzt Collector-Resultat konsistent via `R`. (2026-02-11)
- Stats: `ShowFuelupStats` nutzt Collector-Resultat konsistent via `R`. (2026-02-11)
- Stats: JSON-Renderer auf R-Parameter-Namenskonvention angepasst. (2026-02-11)
- Stats: CSV-Renderer an Vorgabe angepasst (feste Kopfzeilen, Rows via CsvJoin, striktes Token nur fuer Month). (2026-02-11)
- Stats: Collector-Init auf FillChar/Nullstart umgestellt (vereinheitlicht). (2026-02-11)
- Stats: JSON-Writer (compact/pretty) fuer `RenderFuelupStatsJson` eingefuehrt. (2026-02-11)
- Stats: Sammelstruktur + Collector/Renderer fuer Fuelup-Stats eingefuehrt. (2026-02-11)
- Stats: CSV-Ausgabe fuer Zyklen/Monate in `u_stats.pas` ergaenzt. (2026-02-11)
- Stats: JSON-Pretty-Overload eingefuehrt; Standardausgabe nun kompakt. (2026-02-11)
- Stats: Monats-Textausgabe zeigt nur die Monats-Tabelle (keine Zyklusliste). (2026-02-11)
- Docs: README/BENUTZERHANDBUCH/STATUS/ARCHITECTURE auf CSV/JSON-Stand aktualisiert. (2026-02-11)
- CLI: Kalender-validiertes Datums-Parsing fuer `YYYY-MM-DD` implementiert. (2026-02-09)
- Build: DateUtils fuer Datumsarithmetik (`IncDay`, `IncMonth`) eingebunden. (2026-02-09)
- Stats: Public API von `u_stats.pas` um Overloads mit Zeitraum-Parametern erweitert. (2026-02-09)
- Stats: `ShowFuelupStats`/`ShowFuelupStatsJson` Signaturen um `Monthly` erweitert. (2026-02-10)
- Stats: Monatsaggregation (Text) fuer `--stats fuelups --monthly` ergaenzt. (2026-02-10)
- Stats: JSON-Ausgabe fuer `--stats fuelups --json --monthly` mit `kind: "fuelups_monthly"`. (2026-02-10)
- Stats: Debug-Helper `DbgEffectivePeriod` eingefuegt (open-ended/closed, no-rows Hinweis). (2026-02-09)
- Stats: Effektiver Zeitraum nach Kopf-Query einmalig geloggt (Text + JSON). (2026-02-09)
- Stats: Zyklus-Algorithmus kanonisiert (Sammler nur zwischen Volltanks; End-Volltank schliesst Zyklus). (2026-02-09)
- Stats: Accumulator-Namen vereinheitlicht (`Acc*` statt `Bucket*`). (2026-02-09)
- Docs: README/STATUS um Stats-Debug-Hinweis (Kopf-Query, open-ended/closed, no-rows) ergaenzt. (2026-02-09)
- Stats: `ShowFuelupStats(DbPath)`/`ShowFuelupStatsJson(DbPath)` als Wrapper auf die Overloads umgestellt. (2026-02-09)

### Fixed (Codex)
- CLI: `--csv`/`--pretty` werden nach Parsing zentral validiert; Kombinationen mit `--json` werden sauber abgelehnt. (2026-02-11)
- Stats: Advanced records aktiviert und Monats-Sortierung auf lokale Kopie umgestellt (const-sicher). (2026-02-11)
- Stats: Zyklusabschluss zaehlt End-Volltank in Liter- und Kosten-Summe (kein 0,0 bei Endtank ohne Teilbetankung). (`units/u_stats.pas`) (2026-02-10)
- Build: `--to` Parsing ohne inline `var` (objfpc-kompatibel). (2026-02-09)
- Build: `TryParseYYYYMMDD` gibt nun korrekt `Result` und Werte zurueck. (2026-02-09)
- Stats: `u_stats.pas` Compile-Fixes (doppelte Var-Deklaration, `Q.SQL.Text` ohne `+=`). (2026-02-09)
- Stats: `ShowFuelupStatsJson` fehlende Eff-Variablen ergänzt; doppelte Eff-Deklaration bereinigt. (2026-02-09)
- Stats: NULL-sichere Summen/Counts (`FieldInt64OrZero`) zur Vermeidung leerer Integer-Konvertierung. (2026-02-09)

## 0.4.2 – 2026-02-07
### Added
- Vorbereitung auf Subcommands (internes Modell), CLI bleibt unverändert.
- Neues Backup-Skript `kpr.sh`: tar von docs/src/units, SHA-256 + JSON-Log. (2026-02-04)
- Stats: JSON-Ausgabe fuer `--stats fuelups` (`--json`). (2026-02-07)

### Changed
- u_db_init: Header auf einheitliches UPDATED/AUTHOR-Format gebracht. (2026-02-07)
- u_fmt: Header-Hinweis zum Dezimaltrennzeichen korrigiert. (2026-02-07)
- u_stats: Header um JSON-Stats ergaenzt. (2026-02-07)
- CLI: `--json` für `--stats fuelups` ergänzt (Parsing, Validierung, Usage, Dispatch). (2026-02-07)
- Stats: Leerzeile zwischen Header und Tabelle ergänzt. (2026-02-07)
- Docs: Stand-Datum in `INITIAL_CONTEXT.md` und `CONSTRAINTS.md` auf 2026-02-07 aktualisiert. (2026-02-07)
- Docs: Release-Logging in `DESIGN_PRINCIPLES.md` und `STATUS.md` ergänzt. (2026-02-07)
- Docs: Hinweis auf `kpr.sh` (Release-Log) in README/ARCHITECTURE ergänzt. (2026-02-07)
- Backup: `kpr.sh` loggt Release-Infos in `release_log.json` und erfasst Quellen im JSON. (2026-02-07)
- Stats: Header-UPDATED in `u_stats.pas` auf 2026-02-07 gesetzt. (2026-02-07)
- Stats: Zyklus-Tabelle erst nach Header/Checks ausgeben; Kosten klarer zwischen SQL-Summe und Zyklus-Summe getrennt. (2026-02-07)
- Docs: README/ARCHITECTURE/STATUS auf aktuellen Funktionsumfang gebracht (Fuelups, Stats-Kosten, Tabellen-Renderer, Input-Parsing, JSON). (2026-02-07)
- Logging-Doku: Quiet unterdrueckt explizit alle Ausgaben; `Dbg(...)` nutzt `[TRC]`. (2026-02-04)
- Design-Prinzipien: neue Ausgabe- & Logging-Regel plus Quiet Output Policy (`--quiet`). (2026-02-04)
- Stats: `total_cents` in den SELECTs erfasst und im Debug geloggt. (2026-02-04)
- Stats: Aggregation von `total_cents` und Gesamtkosten-Ausgabe ergänzt. (2026-02-04)
- Stats: Gesamtkosten mit Tausenderpunkt formatiert. (2026-02-04)
- Stats: Tabellen-Setup mit TTable-Spalten initialisiert (Vorbereitung Renderer). (2026-02-04)
- Stats: Zyklusabschluss fügt Tabellenzeile inkl. Kosten hinzu. (2026-02-04)
- Stats: Gesamtzeile (Summe) via TTable-Footer ergänzt. (2026-02-04)
- Stats: TTable-Ausgabe via `T.Write` ergänzt. (2026-02-04)
- Stats: Kostenformatierung in `FormatCentsAsEuro` auf Integer-Format umgestellt. (2026-02-04)
- Tabellen-Renderer: `TTable` in `u_table` ergänzt (Spalten, Zeilen, Separator, Write). (2026-02-04)
- Tabellen-Renderer: Separatoren unterstützen jetzt Doppellinie fuer Footer (`=`). (2026-02-04)
- Tabellen-Renderer: Header-Trennlinie als Doppellinie formatiert. (2026-02-04)
- u_stats: Header-Doku an aktuellen Funktionsumfang angepasst. (2026-02-04)
- u_table: Header-Doku um TTable-Renderer erweitert. (2026-02-04)
- Stats: Kosten gesamt wieder strikt als Fixed-Point formatiert. (2026-02-04)
- Stats: Kraftstoff-Ausgabe nutzt Fixed-Point-Formatter statt Float. (2026-02-04)
- Stats: Summenzeile wird nur bei vorhandenen Zyklen in die Tabelle gesetzt. (2026-02-04)
- Stats: Ausgabe-Block nach DB-Block gezogen (Lesbarkeit). (2026-02-04)
- Stats: Tabellen-Write direkt nach Summenzeile platziert. (2026-02-04)

### Fixed
- `--quiet` unterdrueckt jetzt auch die leere Zeile vor der Debug-Tabelle. (2026-02-04)

---

## 0.4.1 – 2026-02-03
### Added
- `--stats fuelups` mit Volltank-Zyklus-Auswertung (Strecke, Verbrauch, Zeitraum).
- `u_stats.pas` als neue Unit fuer Auswertungen.
- `--trace` fuer gezielte Trace-Ausgaben.
### Changed
- Logging-Policy: informative Ausgaben ueber `Msg(...)` (respektiert Quiet).
- Debug/Trace getrennt: `Dbg` nutzt Trace, Debug-Tabelle bleibt bei `--debug`.
### Fixed
- Ausgaben bei `--seed` in Quiet sauber und maschinenfreundlich.

---

## 0.4.0 – 2026-02-01
### Added
- Demo-DB-Workflow: `--seed` zum Erzeugen/Aktualisieren, `--demo` zur Nutzung.
- Seed-Parameter: `--stations`, `--fuelups`, `--seed-value`, `--force`.
- Erweiterte Usage-/Hilfeausgabe inkl. Beispiele und Hinweise.
### Changed
- CLI-Policy erweitert: `--seed` ist exklusiv und nutzt immer die Demo-DB.
- Demo-Seed-Daten auf ASCII angepasst (Umlaute als ae/oe/ue).
### Fixed
- Stabilere Fehlerausgabe beim Seeding (saubere Fehlermeldung statt Stacktrace).
- `sqlite_sequence`-Reset defensiv, falls Tabelle fehlt.

---

## 0.3.0 – 2026-01-28
### Added
- Vollständige Fachlogik für Betankungen (`fuelups`): add / list / `--detail`, JOIN auf `stations`
- Bon-exaktes Parsing für `fuelups` (skalierte Integer, keine Float-Rundungsfehler)
- Striktes Transaktionshandling pro Business-Aktion (fuelups)
- Neues, standardisiertes Header-System für alle Units zur besseren Wartbarkeit
### Changed
- Schema-Version auf v3 aktualisiert (inkl. `fuelups`)

---

## 0.2.2 – 2026-01-21 (Projektstruktur & DB-Pfad-Handling)
### Added
- **Persistenz:** DB-Pfad wird nun in `~/.config/Betankungen/config.ini` gespeichert.
- **XDG-Support:** Automatische Nutzung von Standardverzeichnissen für Daten und Konfiguration.
- **CLI-Tools:** Befehle `--show-config` und `--reset-config` für einfachere Wartung hinzugefügt.
- **Flexibilität:** Mit `--db` kann der Pfad nun für einzelne Aufrufe überschrieben werden.

### Fixed
- Build-Umgebung: Inkonsistenzen zwischen Lazarus-IDE und VS Code (fpc) behoben.
- Bereinigung verwaister Lazarus-Projekt-Metadaten.

---

## 0.2.1 – Stabilisierung & Dokumentation
### Changed
- **Robustheit:** Umfassende Einführung von `try...finally` zur sicheren Ressourcen-Freigabe (Memory Leaks verhindert).
- **UX:** Fehlermeldungen verständlicher gestaltet und interaktive Texte verfeinert.
- **Logging:** Debug-Ausgaben vereinheitlicht und lesbarer formatiert.


---

## 0.2.0 – Stations-CRUD
- Vollständige CRUD-Funktionalität für `stations`
- Interaktive Eingabe und Bearbeitung
- Alt-/Neu-Vergleich bei Änderungen
- Detail- und Standardlisten
- UNIQUE-Constraint auf Adresse
- Debug-Logging mit Tabellenlayout
- Zentrale Logging-Unit (`u_log`)

---

## 0.1.0 – Initiale Basis
- SQLite-Initialisierung (`EnsureDatabase`)
- Technische Meta-Tabelle (`meta`)
- Schema-Versionierung
- CLI-Grundgerüst mit Flag-Parsing
- Debug- und Quiet-Modus
