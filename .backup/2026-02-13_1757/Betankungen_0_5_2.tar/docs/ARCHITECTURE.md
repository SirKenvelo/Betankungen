# System-Architektur & Design-Dokumentation
**Stand:** 2026-02-12

Dieses Dokument beschreibt die zentralen Designentscheidungen, die Architekturprinzipien und die langfristige Roadmap des Projekts **"Betankungen"**.

---

## Zentrale Designentscheidungen (ADR)

*   **Immutable IDs:** Primärschlüssel (IDs) werden niemals neu vergeben. Einmal vergebene IDs bleiben permanent mit ihrem Datensatz verknüpft, um die Referenzintegrität (z. B. in Backups oder Log-Files) zu garantieren.
*   **Single-Table Source of Truth:** Bevorzugung einer klaren Tabellenstruktur gegenüber künstlicher Über-Normalisierung, um die Abfrage-Logik (SQL) simpel und performant zu halten.
*   **Command-Exclusivity:** Das CLI-Interface folgt einem strikten Dispatcher-Modell. Pro Aufruf wird genau eine Hauptaktion (Add, List, Edit, Delete, Seed oder Stats) ausgeführt, was Fehlbedienungen verhindert.
*   **Separation of Concerns (SoC):** Strikte Trennung zwischen Geschäftslogik (`Business Logic`) und Anzeige/Eingabe (`UI`). Die Fach-Units (z. B. `u_stations`) enthalten keine CLI-Parsing-Logik.
*   **Transaktions-Sicherheit:** Jede Datenbank-Mutation (Schreiben, Ändern, Löschen) wird als atomare Einheit behandelt. Schlägt ein Teil fehl, erfolgt ein vollständiger Rollback (All-or-Nothing).
*   **Defensive Parsing:** "Garbage in, Garbage out" wird an der Systemgrenze verhindert. Eingaben werden über skalierte Integer-Funktionen (Fixed-Point) validiert, bevor sie die Fachlogik erreichen.

---

## Aktueller Funktionsumfang (Stand 2026-02-12)
Siehe `CHANGELOG.md`, Version `0.5.2`.

### Infrastruktur & Tooling
- [x] **XDG-Konformität:** Trennung von Daten (`~/.local/share/`) und Konfiguration (`~/.config/`).
- [x] **Zentrales DB-Handling:** Unterstützung für Default-Pfade, persistente INI-Konfiguration und CLI-Overrides via `--db`.
- [x] **Build-Integration:** Vollständige Synchronisation zwischen Lazarus-IDE und VS Code Build-Tasks.
- [x] **Logging-System:** Global steuerbares Logging mit Debug-Tabelle und Trace-Ausgaben.
- [x] **Demo-DB:** Separater Seed-Workflow via `--seed` und Nutzung via `--demo`.
- [x] **Tabellen-Renderer:** Leichtgewichtige Tabellen-Ausgabe via `TTable` (Stats).
- [x] **Release-Logging:** Archiv + SHA-256 in `release_log.json` per `kpr.sh`.

### Daten & Logik
- [x] **DB-Bootstrap:** Idempotente Initialisierung des SQLite-Schemas inkl. Metadaten-Tracking.
- [x] **Stations-CRUD:** Vollständige Verwaltung von Tankstellen (Anlegen, Auflisten, Bearbeiten, Löschen).
- [x] **Fixed-Point Engine:** Präzises Parsing von Währungen/Volumina via `u_db_common` ohne Fließkomma-Fehler.
- [x] **CSV-Helper (strict):** `u_fmt` stellt strikte CSV-Token/Zeilen ohne Escaping bereit (CSV-Output fuer Stats vorhanden, kein breiter Export).
- [x] **Interaktive UX:** Benutzerführung mit Sicherheitsabfragen und Validierung von Pflichtfeldern.
- [x] **Fuelups:** `u_fuelups.pas` implementiert (Add/List inkl. Detail-Ansicht, JOIN auf `stations`).
- [x] **Stats:** `--stats fuelups` mit Volltank-Zyklus-Auswertung inkl. Kosten.
- [x] **Schema v3:** Tabelle `fuelups` inkl. Foreign Key auf `stations`.

---

## Roadmap & Evolution

### Version 0.3.0 – Fuelups (Kernfeature) — abgeschlossen
*Ziel: Erfassung und Speicherung von Tankereignissen.*
- [x] Schema v3 mit Tabelle `fuelups` und Foreign Key auf `stations`.
- [x] Unit `u_fuelups.pas` implementiert.
- [x] Commands `--add fuelup` und `--list fuelups` (inkl. `--detail`).

### Version 0.4.0 – Demo-DB & Seed — abgeschlossen
*Ziel: Reproduzierbare Demo-Daten fuer Tests und Vorfuehrungen.*
- [x] Seed-Workflow fuer Demo-DB (`--seed`) inkl. Force/SeedValue.
- [x] Demo-DB-Nutzung fuer einen Lauf (`--demo`).
- [x] Erweiterte CLI-Hilfe inkl. Beispiele und Hinweise.

### Version 0.4.1 – Stats & Logging — abgeschlossen
*Ziel: Auswertungen und klarere Diagnoseausgaben.*
- [x] `--stats fuelups` (Volltank-Zyklen, Strecke, Verbrauch, Zeitraum).
- [x] Logging-Policy: `Msg` fuer informative Ausgaben, `Dbg` fuer Trace.
- [x] `--trace` als separates Diagnose-Flag.

### Version 0.4.2 – JSON-Stats — abgeschlossen
*Ziel: Maschinenlesbare Stats-Ausgabe.*
- [x] `--stats fuelups --json` (JSON-Output der Zyklusdaten).
- [x] CLI-Validierung: `--json` nur mit `--stats fuelups`.

### Version 0.5.0 – Komfort & Auswertung
*Ziel: Daten nutzbar machen.*
- [x] Filter & Zeitraeume fuer `--stats fuelups`: `--from`/`--to` (YYYY-MM-DD; optional YYYY-MM).
- [x] Filter wirken auf Kopfwerte (Zeitraum, Counts) und Zyklusbildung (nur Fuelups im Zeitraum).
- [x] Keine Datenmanipulation: nur `SELECT` + Berechnung.
- [x] Periodische Auswertungen: Monats-Summary (km, liters_ml, avg, total_cents).
- [ ] Optional: Jahres-Summary aus Monatsbloecken aggregiert.
- [x] Output: Tabelle (Text) und JSON mit `kind: "fuelups_monthly"`.
- [x] CSV-Output fuer Stats (strict, CLI + API).
- [x] Konsolen-Dashboards fuer die Auswertung (kompakt, scanbar, ohne CLI-Umbau).
- [ ] Export-Story: JSON bleibt Source of Truth; breiter CSV-Export weiterhin offen (nach 0.5.2).
- [x] Umsetzungsschritte: 1) `--from`/`--to` Parser + Validierung. 2) Stats-Query mit `WHERE fueled_at BETWEEN ...`. 3) Zyklusgrenzen im Zeitraum. 4) Monatsaggregation. 5) JSON-Schema erweitern (neue kinds, `period` bleibt).
- [ ] Nicht-Ziele 0.5.0: keine Station-Filter, keine Multi-Car-Logik, kein Import/Sync/Editor, kein CLI-Umbau (keine neuen Subcommands).

### Version 0.5.2 – Dashboard & Unicode-Box-Engine — abgeschlossen
*Ziel: Kompakte, scanbare Stats-Ansicht ohne CLI-Umbau.*
- [x] Dashboard-Renderer via `--stats fuelups --dashboard` im CLI verfuegbar.
- [x] Unicode-Box-Engine in `u_fmt` fuer kompakte Status-/Dashboard-Ausgaben.
- [x] UTF-8-sichere Breitenberechnung fuer stabiles Layout bei Mehrbyte-Zeichen.
- [x] Dynamische Farblogik fuer Kostenbalken (relativ/statisch).
- [x] Exklusive Flag-Validierung (`--dashboard` vs `--json`/`--csv`).

Festgezurrte Detailentscheidungen (2026-02-09)
- Offene Grenzen bei Filtern sind datengetrieben: nur `--from` => `to = MAX(fueled_at)`, nur `--to` => `from = MIN(fueled_at)` (kein "heute").
- Zyklusregel am Rand: Zyklus zählt nur, wenn Start- und End-Volltank im Zeitraum liegen (vollständig im Zeitraum).
- JSON-avg: `avg_l_per_100km` als scaled Integer (z. B. `avg_l_per_100km_x100`), keine Strings.

### Langfristig (v1.0.0+)
- [ ] Daten-Interoperabilitaet: vollstaendiger CSV-Export fuer externe Analysen.
- [ ] Batch-Import: Migrationstools für Altdaten aus Drittsystemen.
- [ ] Unterstützung für mehrere Fahrzeuge innerhalb einer Datenbank.

---

## Meta-Fazit
Das Projekt ist als robuste CLI-Anwendung konzipiert, mit klaren Schichten, stabiler Datenhaltung und konsistenter Benutzerfuehrung. Die Architektur ist modular und transaktionssicher, die Verantwortlichkeiten sind sauber getrennt, und die Basis ist bewusst so gehalten, dass kuenftige Auswertungen und Erweiterungen ohne strukturelle Brueche moeglich sind.
