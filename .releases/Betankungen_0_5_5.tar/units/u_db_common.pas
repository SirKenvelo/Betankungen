{
  u_db_common.pas
  ---------------------------------------------------------------------------
  UPDATED: 2026-02-03
  AUTHOR : Christof Kempinski
  Zentrale Infrastruktur für Konsolen-Interaktion und striktes Daten-Parsing.

  Aufgaben:
  - Abstraktion von ReadLn/WriteLn für konsistente Benutzereingaben.
  - Validierung von Pflichtfeldern und "Keep-Existing"-Logik für Edit-Dialoge.
  - Hochpräzises Parsing von Strings in skalierte Ganzzahl-Typen (Fixed-Point).

  Wichtige Konzepte:
  - Fixed-Point-Arithmetik: Um Rundungsfehler von 'Double' zu vermeiden, werden
    Währungen (Cents) und Volumina (ml) als Int64 verarbeitet.
  - Strict Parsing: Diese Unit erzwingt korrekte Nachkommastellen (z.B. 2 für EUR),
    um Fehleingaben bereits an der UI-Grenze abzufangen.
  - Trennung: Enthält Logik für den Dialogfluss, aber keine Datenbank-Logik.

  Hinweis: Alle Parse-Funktionen normalisieren Eingaben (ersetzen ',' durch '.').
  ---------------------------------------------------------------------------
}

unit u_db_common;

{$mode objfpc}{$H+}

interface

type
  TParseInt64Func = function(const S: string): Int64;
  TFormatInt64Func = function(const V: Int64): string;

const
  // Rueckgabewert fuer "leer" bei optionalen Zahlenfeldern
  EMPTY_INT64 = Low(Int64);

// ----------------
// Eingabe-Helfer

function AskRequired(const Prompt: string): string;
function AskOptional(const Prompt: string): string;

// Eingabetaste = behalten (nuetzlich beim Editieren)
function AskKeep(const Prompt, Current: string): string;

// Pflichtfelder pruefen (fuer Edit + Add)
procedure EnsureNotEmpty(const FieldName, Value: string);

// Einfache Ja/Nein-Abfrage (spaeter erweiterbar)
function AskYesNo(const Prompt: string; DefaultNo: boolean = True): boolean;

// Parsing-Helfer (fuer fuelups spaeter wichtig)
function ParseScaledIntExactOneOf(const S: string; const ADecimals1, ADecimals2: Integer; const AName: string): Int64;
function ParseScaledIntExact(const S: string; const ADecimals: Integer; const AName: string): Int64;
function ParseLitersToMl(const S: string): int64;
function ParseEuroToCents(const S: string): int64;
function ParseEurPerLiterToMilli(const S: string): int64;
function AskAndParseInt64(
  const Prompt: string;
  ParseFunc: TParseInt64Func;
  FormatFunc: TFormatInt64Func;
  const LabelName: string;
  AllowEmpty: boolean = False // wenn True: Rueckgabe EMPTY_INT64 bei leerer Eingabe
): Int64;

implementation

uses
  SysUtils, Math;

function AskRequired(const Prompt: string): string;
var
  Input: string;
begin
  repeat
    Write(Prompt);
    ReadLn(Input);
    Input := Trim(Input);
    if Input = '' then
      WriteLn('Fehler: Diese Eingabe darf nicht leer sein!');
  until Input <> '';
  Result := Input;
end;

function AskOptional(const Prompt: string): string;
var
  Input: string;
begin
  Write(Prompt);
  ReadLn(Input);
  Result := Trim(Input);
end;

function AskKeep(const Prompt, Current: string): string;
var
  Input: string;
begin
  Write(Prompt, ' [', Current, ']: ');
  ReadLn(Input);
  Input := Trim(Input);
  if Input = '' then
    Result := Current
  else
    Result := Input;
end;

procedure EnsureNotEmpty(const FieldName, Value: string);
begin
  if Trim(Value) = '' then
    raise Exception.Create('Pflichtfeld darf nicht leer sein: ' + FieldName);
end;

function AskYesNo(const Prompt: string; DefaultNo: boolean): boolean;
var
  S: string;
begin
  if DefaultNo then
    Write(Prompt, ' (y/N): ')
  else
    Write(Prompt, ' (Y/n): ');

  ReadLn(S);
  S := LowerCase(Trim(S));

  if S = '' then
    Exit(not DefaultNo);

  Result := (S = 'y') or (S = 'yes') or (S = 'j') or (S = 'ja');
end;

function AskAndParseInt64(
  const Prompt: string;
  ParseFunc: TParseInt64Func;
  FormatFunc: TFormatInt64Func;
  const LabelName: string;
  AllowEmpty: boolean = False
): Int64;
var
  S: string;
begin
  while True do
  begin
    Write(Prompt);
    ReadLn(S);
    S := Trim(S);

    // Abbruch
    if (LowerCase(S) = 'q') or (LowerCase(S) = 'quit') then
      raise Exception.Create(LabelName + ': Abgebrochen durch Benutzer.');

    // Optionales Feld
    if AllowEmpty and (S = '') then
      Exit(EMPTY_INT64); // Konvention: "leer" ist eindeutig von Null unterscheidbar

    if (not AllowEmpty) and (S = '') then
    begin
      WriteLn('Fehler: Eingabe darf nicht leer sein. (oder q zum Abbrechen)');
      Continue;
    end;

    try
      Result := ParseFunc(S);

      // Bestaetigung: zeigt formatierten und rohen Wert
      WriteLn('OK: ', LabelName, ' = ', FormatFunc(Result),
              '  [raw=', Result, ']');

      Exit;
    except
      on E: Exception do
      begin
        WriteLn('Fehler: ', E.Message);
        WriteLn('Bitte erneut eingeben (oder q zum Abbrechen).');
      end;
    end;
  end;
end;

function ParseScaledIntExact(const S: string; const ADecimals: Integer; const AName: string): Int64;
var
  T, IntPart, FracPart: string;
  P, I: Integer;
  Scale: Int64;
begin
  T := Trim(S);
  if T = '' then
    raise Exception.Create(AName + ': Eingabe ist leer');

  if T[1] = '-' then
    raise Exception.Create(AName + ': Wert darf nicht negativ sein');

  // Normalisieren: Komma wird zu Punkt
  T := StringReplace(T, ',', '.', [rfReplaceAll]);

  // Split an Punkt
  P := Pos('.', T);
  if P > 0 then
  begin
    IntPart := Copy(T, 1, P-1);
    FracPart := Copy(T, P+1, Length(T));
  end
  else
  begin
    IntPart := T;
    FracPart := '';
  end;

  if IntPart = '' then IntPart := '0';

  // Nur Ziffern erlauben
  for I := 1 to Length(IntPart) do
    if not (IntPart[I] in ['0'..'9']) then
      raise Exception.Create(AName + ': Ungültige Zahl "' + S + '"');

  for I := 1 to Length(FracPart) do
    if not (FracPart[I] in ['0'..'9']) then
      raise Exception.Create(AName + ': Ungültige Zahl "' + S + '"');

  // Exakt ADecimals Nachkommastellen verlangen
  if Length(FracPart) <> ADecimals then
    raise Exception.Create(AName + ': Erwartet genau ' + IntToStr(ADecimals) +
      ' Nachkommastellen (z.B. 1.' + StringOfChar('0', ADecimals) + ')');

  Scale := Trunc(IntPower(10, ADecimals));
  Result := StrToInt64(IntPart) * Scale;

  if ADecimals > 0 then
    Result := Result + StrToInt64(FracPart);
end;

function ParseScaledIntExactOneOf(const S: string; const ADecimals1, ADecimals2: Integer; const AName: string): Int64;
var
  T: string;
  P: Integer;
  FracLen: Integer;
begin
  T := Trim(S);
  if T = '' then
    raise Exception.Create(AName + ': Eingabe ist leer');

  if T[1] = '-' then
    raise Exception.Create(AName + ': Wert darf nicht negativ sein');

  T := StringReplace(T, ',', '.', [rfReplaceAll]);

  P := Pos('.', T);
  if P > 0 then
    FracLen := Length(T) - P
  else
    FracLen := 0;

  if not ((FracLen = ADecimals1) or (FracLen = ADecimals2)) then
    raise Exception.Create(AName + ': Erwartet genau ' + IntToStr(ADecimals1) +
      ' oder ' + IntToStr(ADecimals2) + ' Nachkommastellen.');

  // Wir speichern auf drei Dezimalstellen skaliert (ml).
  if FracLen = 2 then
    Result := ParseScaledIntExact(T + '0', 3, AName)
  else
    Result := ParseScaledIntExact(T, 3, AName);
end;

// ----------------
// Oeffentliche Wrapper

function ParseEuroToCents(const S: string): Int64;
begin
  // Exakt zwei Nachkommastellen
  Result := ParseScaledIntExact(S, 2, 'EUR');
end;

function ParseEurPerLiterToMilli(const S: string): Int64;
begin
  // Exakt drei Nachkommastellen
  Result := ParseScaledIntExact(S, 3, 'EUR/L');
end;

function ParseLitersToMl(const S: string): Int64;
begin
  // Exakt zwei oder drei Nachkommastellen (bon-abhaengig), gespeichert als ml
  Result := ParseScaledIntExactOneOf(S, 2, 3, 'Liter');
end;
end.