# Betankungen
**Stand:** 2026-02-11
CLI-Projekt mit Free Pascal / Lazarus & SQLite

---

## Ziel

**Betankungen** ist ein terminalbasiertes CLI-Projekt, das schrittweise zu einer
real nutzbaren Anwendung wächst.

Der Fokus liegt bewusst auf:

- klarer Architektur
- sauberer Trennung von Verantwortung
- robuster, nachvollziehbarer Implementierung
- Wartbarkeit statt „Quick & Dirty“

Das Projekt ist **lernorientiert**, aber nicht als Spielzeug gedacht.

---

## Architektur – Überblick

- Terminalbasierte CLI-Anwendung (bewusst ohne GUI)
- SQLite als lokale Datenbank (eine Datei, kein Server)
- Modularer Aufbau mit klar getrennten Units
- Keine Fach- oder SQL-Logik im Hauptprogramm
- Demo-Datenbank fuer Tests und Vorfuehrungen (`--seed`, `--demo`)

**Zentrale Idee:**
Das Hauptprogramm steuert – die Units arbeiten.

---

## Projektstruktur

### `Betankungen.lpr`
Einstiegspunkt und Orchestrator der Anwendung.

**Aufgaben**
- Parsen und Validieren der CLI-Argumente
- Aktivieren von Modus-Flags (`--debug`, `--trace`, `--quiet`, `--detail`)
- Initialisierung der SQLite-Datenbank
- Sicherstellen, dass genau **ein** Kommando ausgeführt wird
- Dispatch an die zuständigen Fach-Units
- Verwaltung der Demo-DB (Erzeugen via `--seed`, Nutzung via `--demo`)
- Ausgabe von Statistiken (`--stats fuelups`)

---

### `u_db_init.pas`
Technisches DB-Bootstrapping.

**Verantwortung**
- Anlegen der Datenbankdatei
- Erstellen und Aktualisieren des Schemas (idempotent)
- Pflege technischer Metadaten (`meta`)
- Schema-Versionierung

---

### `u_db_common.pas`
Zentrale Infrastruktur für Konsolen-Interaktion und striktes Daten-Parsing.

**Verantwortung**
- Eingabe-Helper (Pflicht/Optional/Keep)
- Validierung von Pflichtfeldern
- Fixed-Point-Parsing (EUR, Liter, EUR/L) ohne Float

---

### `u_db_seed.pas`
Demo-Datenbank-Modul.

**Verantwortung**
- Erzeugt/aktualisiert eine separate Demo-DB (`--seed`)
- Befüllt Demo-Daten für `stations` und `fuelups`
- Optionale Reproduktion via `--seed-value` und Reset via `--force`

---

### `u_log.pas`
Zentrale Logging- und Debug-Unit.

**Features**
- Trace-Ausgaben via `Dbg(...)` (nur bei `--trace`)
- Strukturierte Debug-Tabelle (`--debug`)
- Optionale ANSI-Farben
- Global steuerbar

---

### `u_fuelups.pas`
Fachlogik für Betankungen (`fuelups`).

**Funktionen**
- Hinzufügen
- Auflisten (Standard / Detail)
- Append-only (keine Edit/Delete)

---

### `u_stats.pas`
Statistik-Modul für Betankungen (`fuelups`).

**Funktionen**
- Volltank-Zyklus-Auswertung (`--stats fuelups`)
- Zeitraum, Strecke, Verbrauch, Kosten
- Tabellarische Zyklusliste inkl. Summenzeile (Standardmodus)
- JSON-Ausgabe (`--stats fuelups --json`, standardmaessig kompakt; Pretty optional via `--pretty`)
- CSV-Ausgabe (strict, maschinenlesbar) fuer Zyklen/Monate (`--stats fuelups --csv`)
- Monatsstatistik (`--stats fuelups --monthly`, Monats-Tabelle ohne Zyklusliste)
- JSON-Monatsausgabe (`--stats fuelups --json --monthly`, `kind: "fuelups_monthly"`)
- JSON-avg als scaled Integer: `avg_l_per_100km_x100`
- Debug: Effektiver Zeitraum wird einmalig nach der Kopf-Query geloggt (open-ended/closed, plus no-rows Hinweis)

Beispiel (JSON, pretty formatiert, gekuerzt):
```json
{
  "kind": "fuelups_full_tank_cycles",
  "period": {"from": "2025-01-01 00:00:00", "to": "2025-02-28 23:59:59"},
  "fuelups_total": 12,
  "fuelups_full": 7,
  "cycles": [
    {"idx": 1, "dist_km": 523, "liters_ml": 38210, "avg_l_per_100km_x100": 731, "total_cents": 6245}
  ],
  "sum": {"cycles": 3, "dist_km": 1460, "liters_ml": 104900, "avg_l_per_100km_x100": 719, "total_cents_all": 18240, "total_cents_cycles": 17650}
}
```

Beispiel (JSON monthly, pretty formatiert, gekuerzt):
```json
{
  "kind": "fuelups_monthly",
  "period": {"from": "2025-01-01 00:00:00", "to": "2025-02-28 23:59:59"},
  "fuelups_total": 12,
  "fuelups_full": 7,
  "rows": [
    {"month":"2025-01", "dist_km": 523, "liters_ml": 38210, "avg_l_per_100km_x100": 731, "total_cents": 6245}
  ]
}
```

---

### `u_stations.pas`
Fachlogik für Tankstellen (`stations`).

**Funktionen**
- Hinzufügen
- Auflisten (Standard / Detail)
- Bearbeiten (Alt-/Neu-Vergleich)
- Löschen mit Sicherheitsabfrage

---

### `u_table.pas`
Leichter Tabellen-Renderer für kompakte CLI-Ausgaben.

**Funktionen**
- Spalten/Zeilen/Separatoren
- Kopf-/Footer-Rendering

---

### `u_fmt.pas`
Formatierungs- und Ausgabelogik für CLI.

**Funktionen**
- Fixed-Point-Formatter (Cents, ml, EUR/L)
- Fuelups-Tabellenlayout inkl. Detailzeilen
- CSV-Helper fuer strikt maschinenlesbare Zeilen (ohne Escaping)

---

## Werkzeuge

### `kpr.sh`
Release-/Backup-Skript für das Projekt.

**Funktionen**
- Erstellt `Betankungen.tar` aus `docs`, `src`, `units`
- Schreibt Prüfsumme + Metadaten in `release_log.json` (Projektroot)
