{
  Betankungen.lpr
  ---------------------------------------------------------------------------
  CREATED: 2026-01-19
  UPDATED: 2026-02-11
  AUTHOR : Christof Kempinski
  Haupteinstiegspunkt und Kommandozeilen-Schnittstelle (CLI) der
  Betankungs-Verwaltung.

  Verantwortlichkeiten:
  - CLI-Steuerung: BuildCommand (Parsing + Regelpruefung) und
    Steuerung des Programmflusses (Hinzufuegen, Auflisten, Bearbeiten, Loeschen).
  - Demo-Datenbank: Erstellen/aktualisieren der Demo-DB (--seed) und Nutzung
    der Demo-DB fuer einen Lauf (--demo).
  - Konfigurations-Management: XDG-konforme Persistenz von DB-Pfaden per INI
    sowie direkte Speicherung via --db-set.
  - Zustandspruefung: Exklusivitaet von Kommandos, Konfliktpruefung bei DB-Optionen
    sowie Validierung erforderlicher Argumente (BuildCommand).
  - Abhaengigkeitsinjektion: Initialisierung der Datenbankverbindung und
    Weitergabe des Pfad-Kontexts an die zustaendigen Fachmodule.
  - Statistik-Dispatch: Weiterleitung von Zeitraum- und Monatsoptionen
    fuer `--stats fuelups` (Text/JSON/CSV, JSON optional pretty).

  Betriebsmodi:
  - Interaktiver Modus: Erststart-Assistent zur Pfadkonfiguration.
  - Automatisierter Modus: Direkte Ausfuehrung ueber Schalter fuer Skripte/Fortgeschrittene.
  - Diagnose-Modus: Integrierte Hilfe- und Konfigurationsanzeige (--show-config).
  - Meta-Modus: Ausgabe von Hilfe (--help) und Version (--version).
  - Trace-Modus: Einfache Laufzeitmeldungen ueber --trace.
  - Demo-Modus: Nutzung einer separaten Demo-DB (--demo) oder Aufbau per --seed.

  Tabellen / Operationen:
  - Stations: hinzufuegen/auflisten/bearbeiten/loeschen
  - Fuelups: hinzufuegen/auflisten (nur anhaengen)

  Design-Entscheidungen:
  - Minimalismus: Das Hauptprogramm enthaelt keine SQL-Statements oder
    Berechnungslogik; es fungiert rein als Weiterleiter.
  - Fehlersicherheit: Verwendung von EXIT_* bei Parametrierungsfehlern zur
    Unterstuetzung von Shell-Verarbeitungsketten.
  - CLI-Bedienung: Kontextbezogene Beispiele in der Usage-Ausgabe (Fokus-Flag).

  Exit-Codes:
  - 0 OK
  - 1 CLI / Argumentfehler
  - 2 Config / Datei / Pfad
  - 3 DB / SQL
  - 4 Unerwarteter Laufzeitfehler

  Exit-Code-Konstanten:
  - EXIT_OK = 0
  - EXIT_CLI = 1
  - EXIT_CONFIG = 2
  - EXIT_DB = 3
  - EXIT_UNEXPECTED = 4

  Konfigurationspfade (XDG):
  - Config-Datei: ~/.config/Betankungen/config.ini
  - Standard-DB:  ~/.local/share/Betankungen/betankungen.db
  - Demo-DB:      ~/.local/share/Betankungen/betankungen_demo.db
  ---------------------------------------------------------------------------
}
program Betankungen;

{$mode objfpc}{$H+}

uses
  SysUtils,
  DateUtils,
  IniFiles,
  u_db_init,
  u_db_seed,
  u_log,
  u_stations,
  u_fuelups,
  u_stats;

const
  EXIT_OK = 0;
  EXIT_CLI = 1;
  EXIT_CONFIG = 2;
  EXIT_DB = 3;
  EXIT_UNEXPECTED = 4;
  
  // Anwendungsversion fuer --version
  APP_NAME    = 'Betankungen';
  APP_VERSION = '0.5.1';
  APP_AUTHOR  = 'Christof Kempinski';

type
  TTableKind = (tkStations, tkFuelups);

  TCommandKind = (ckNone, ckAdd, ckList, ckEdit, ckDelete, ckSeed, ckStats);

  TCommand = record
    // Hauptaktion
    Kind: TCommandKind;
    Target: TTableKind;     // stations/fuelups
    HasCommand: boolean;    // ob ueberhaupt ein Hauptkommando vorhanden ist

    // Optionen
    Detail: boolean;
    Json: boolean;   // --json (nur fuer: --stats fuelups)
    Monthly: boolean; // --monthly (nur fuer: --stats fuelups)
    Csv: boolean;     // --csv (nur fuer: --stats fuelups), exklusiv
    Pretty: boolean;  // --pretty (nur zusammen mit --json)

    // Zeitraum-Filter (nur fuer: --stats fuelups)
    PeriodEnabled: boolean;
    FromProvided: boolean;
    ToProvided: boolean;

    // Normalisierte Grenzen (SQLite ISO)
    // from: inklusiv  (>=)
    // to : exklusiv  (<)
    PeriodFromIso: string;      // 'YYYY-MM-DD HH:NN:SS'
    PeriodToExclIso: string;    // 'YYYY-MM-DD HH:NN:SS'

    SeedStations: integer;
    SeedFuelups: integer;
    SeedValue: integer;
    SeedForce: boolean;
    UseDemoDb: boolean;

    // Meta
    Help: boolean;
    Version: boolean;
    ShowConfig: boolean;
    ResetConfig: boolean;

    Debug: boolean;
    Trace: boolean;
    Quiet: boolean;

    // DB
    DbOverride: string; // --db
    DbSet: string;      // --db-set

    // Fehlerkontext
    ErrorMsg: string;
    ErrorFocus: string; // z.B. '--db-set', '--add'
  end;

var
  // Pfad zur SQLite-Datenbank
  DbPath: string;
  WasCreated: boolean;

  Cmd: TCommand;

  // ----------------
  // CLI-Helfer: Hilfeausgabe und standardisierter Exit-Code
  procedure PrintUsage(const FocusFlag: string = '');
  begin
    WriteLn('Usage:');
    WriteLn('  Betankungen [--db <pfad>] [--detail] <command>');
    WriteLn('  Betankungen --db-set <pfad>');
    WriteLn('  Betankungen --seed [--stations N] [--fuelups N] [--seed-value N] [--force]');
    WriteLn('  Betankungen --demo [--detail] <command>');
    WriteLn('  Betankungen --stats fuelups [--from YYYY-MM[-DD]] [--to YYYY-MM[-DD]] [--monthly] [--json [--pretty]] [--csv]');
    WriteLn('');

    WriteLn('Commands:');
    WriteLn('  --add stations|fuelups');
    WriteLn('  --list stations|fuelups');
    WriteLn('  --edit stations          (nur stations)');
    WriteLn('  --delete stations        (nur stations)');
    WriteLn('  --stats fuelups          (Volltank-Zyklen, read-only)');
    WriteLn('');

    WriteLn('Aktionen:');
    WriteLn('  --seed');
    WriteLn('    Erstellt oder aktualisiert eine Demo-Datenbank');
    WriteLn('    (immer separate Demo-DB, niemals die produktive DB)');
    WriteLn('  --demo');
    WriteLn('    nutzt Demo-DB für diesen Lauf');
    WriteLn('');

    WriteLn('Hinweise:');
    WriteLn('  --seed darf nicht mit --db, --db-set oder anderen Kommandos kombiniert werden.');
    WriteLn('  --db-set speichert den Pfad und beendet das Programm.');
    WriteLn('');

    WriteLn('Meta:');
    WriteLn('  --show-config');
    WriteLn('  --reset-config');
    WriteLn('  --debug');
    WriteLn('  --trace');
    WriteLn('  --monthly (nur fuer: --stats fuelups)');
    WriteLn('  --json    (nur fuer: --stats fuelups)');
    WriteLn('  --csv     (nur fuer: --stats fuelups; exklusiv, kein Mix)');
    WriteLn('  --pretty  (nur zusammen mit --json)');
    WriteLn('  --quiet');
    WriteLn('');

    WriteLn('Examples:');
    if FocusFlag = '--db' then
    begin
      WriteLn('  Betankungen --db /pfad/zur/db.sqlite --list stations');
    end
    else if FocusFlag = '--db-set' then
    begin
      WriteLn('  Betankungen --db-set /pfad/zur/db.sqlite');
    end
    else if FocusFlag = '--add' then
    begin
      WriteLn('  Betankungen --add stations');
      WriteLn('  Betankungen --add fuelups');
    end
    else if FocusFlag = '--list' then
    begin
      WriteLn('  Betankungen --list stations');
      WriteLn('  Betankungen --list fuelups');
    end
    else if FocusFlag = '--edit' then
    begin
      WriteLn('  Betankungen --edit stations');
    end
    else if FocusFlag = '--delete' then
    begin
      WriteLn('  Betankungen --delete stations');
    end
    else
    begin
      WriteLn('  Betankungen --list stations');
      WriteLn('  Betankungen --add fuelups');
      WriteLn('  Betankungen --seed');
      WriteLn('  Betankungen --seed --force');
      WriteLn('  Betankungen --trace --list fuelups');
      WriteLn('  Betankungen --stats fuelups');
      WriteLn('  Betankungen --stats fuelups --monthly');
      WriteLn('  Betankungen --stats fuelups --json');
      WriteLn('  Betankungen --stats fuelups --from 2025-01 --to 2025-03');
      WriteLn('  Betankungen --stats fuelups --from 2025-02-01 --to 2025-02-28');
      WriteLn('  Betankungen --stats fuelups --from 2025-01 --json');
      WriteLn('  Betankungen --stats fuelups --csv');
      WriteLn('  Betankungen --stats fuelups --monthly --csv');
      WriteLn('  Betankungen --stats fuelups --json --pretty');
      WriteLn('  Betankungen --demo --stats fuelups');
      WriteLn('  Betankungen --demo --stats fuelups --json');
      WriteLn('  Betankungen --demo --list stations');
      WriteLn('  Betankungen --db /pfad/zur/db.sqlite --list fuelups');
      WriteLn('  Betankungen --db-set /pfad/zur/db.sqlite (speichert und beendet)');
    end;
  end;

  // Gibt Fehlermeldung (optional) aus, zeigt Hilfe und beendet mit EXIT_CLI
  procedure FailUsage(const Msg: string; const FocusFlag: string = '');
  begin
    if Msg <> '' then
      WriteLn(Msg);
    WriteLn('');
    PrintUsage(FocusFlag);
    Halt(EXIT_CLI);
  end;

  // Mapping-Helfer
  function CommandKindFromFlag(const S: string; out Kind: TCommandKind): boolean;
  begin
    Result := True;
    if S = '--add' then Kind := ckAdd
    else if S = '--list' then Kind := ckList
    else if S = '--edit' then Kind := ckEdit
    else if S = '--delete' then Kind := ckDelete
    else if S = '--stats' then Kind := ckStats
    else Result := False;
  end;

  // Parst Tabellennamen in Aufzaehlungstyp und erlaubt Singular/Plural.
  function ParseTableKind(const S: string; out Kind: TTableKind): boolean;
  var
    L: string;
  begin
    L := LowerCase(S);
    case L of
      'station', 'stations':
        begin
          Kind := tkStations;
          Exit(True);
        end;
      'fuelup', 'fuelups':
        begin
          Kind := tkFuelups;
          Exit(True);
        end;
    end;
    Result := False;
  end;

  function TryParseYYYYMM(const S: string; out Y, M: word): boolean;
  var
    SY, SM: string;
    iY, iM: integer;
  begin
    Result := False;
    if Length(S) <> 7 then Exit;
    if S[5] <> '-' then Exit;

    SY := Copy(S, 1, 4);
    SM := Copy(S, 6, 2);

    if (not TryStrToInt(SY, iY)) or (not TryStrToInt(SM, iM)) then Exit;
    if (iY < 1900) or (iY > 2200) then Exit;
    if (iM < 1) or (iM > 12) then Exit;

    Y := word(iY);
    M := word(iM);
    Result := True;
  end;

  function TryParseYYYYMMDD(const S: string; out Y, M, D: word): boolean;
  var
    SY, SM, SD: string;
    iY, iM, iD: integer;
    Dt: TDateTime;
  begin
    Result := False;
    if Length(S) <> 10 then Exit;
    if (S[5] <> '-') or (S[8] <> '-') then Exit;

    SY := Copy(S, 1, 4);
    SM := Copy(S, 6, 2);
    SD := Copy(S, 9, 2);

    if (not TryStrToInt(SY, iY)) or (not TryStrToInt(SM, iM)) or (not TryStrToInt(SD, iD)) then Exit;
    if (iY < 1900) or (iY > 2200) then Exit;

    // echte Kalenderprüfung
    if not TryEncodeDate(iY, iM, iD, Dt) then Exit;

    Y := word(iY);
    M := word(iM);
    D := word(iD);
    Result := True;
  end;

  // ------------------------------------------------------------
  // Zeitraum-Parsing (--from/--to) -> ISO + exklusives Ende
  function TryParseFromToValue(const S: string; out FromIso, ToExclIso: string): boolean;
  var
    Y, M, D: word;
    DtStart, DtEnd: TDateTime;
  begin
    Result := False;
    FromIso := '';
    ToExclIso := '';

    if TryParseYYYYMM(S, Y, M) then
    begin
      DtStart := EncodeDate(Y, M, 1);
      DtEnd := IncMonth(DtStart, 1);
      FromIso := FormatDateTime('yyyy-mm-dd hh:nn:ss', DtStart);
      ToExclIso := FormatDateTime('yyyy-mm-dd hh:nn:ss', DtEnd);
      Exit(True);
    end;

    if TryParseYYYYMMDD(S, Y, M, D) then
    begin
      DtStart := EncodeDate(Y, M, D);
      DtEnd := IncDay(DtStart, 1);
      FromIso := FormatDateTime('yyyy-mm-dd hh:nn:ss', DtStart);
      ToExclIso := FormatDateTime('yyyy-mm-dd hh:nn:ss', DtEnd);
      Exit(True);
    end;
  end;

  // Zentrale CLI-Parsing- und Regelpruefung; liefert Fehlertext + Fokus-Flag.
  function BuildCommand(out Cmd: TCommand): boolean;
  var
    i: integer;
    TmpKind: TCommandKind;
    TmpFromIso, TmpToExclIso: string;
  begin
    FillChar(Cmd, SizeOf(Cmd), 0);
    Cmd.Kind := ckNone;
    Cmd.HasCommand := False;
    Cmd.Target := tkStations; // Standard egal, wird gesetzt, wenn HasCommand True

    Cmd.SeedStations := 10;
    Cmd.SeedFuelups := 100;
    Cmd.SeedValue := 0;
    Cmd.SeedForce := False;
    Cmd.UseDemoDb := False;

    i := 1;
    while i <= ParamCount do
    begin
      // Meta-Optionen
      if ParamStr(i) = '--help' then begin Cmd.Help := True; Inc(i); Continue; end;
      if ParamStr(i) = '--version' then begin Cmd.Version := True; Inc(i); Continue; end;

      // Optionen
      if ParamStr(i) = '--debug' then begin Cmd.Debug := True; Inc(i); Continue; end;
      if ParamStr(i) = '--trace' then begin Cmd.Trace := True; Inc(i); Continue; end;
      if ParamStr(i) = '--quiet' then begin Cmd.Quiet := True; Inc(i); Continue; end;
      if ParamStr(i) = '--detail' then begin Cmd.Detail := True; Inc(i); Continue; end;
      if ParamStr(i) = '--json' then begin Cmd.Json := True; Inc(i); Continue; end;
      if ParamStr(i) = '--monthly' then begin Cmd.Monthly := True; Inc(i); Continue; end;
      if ParamStr(i) = '--csv' then begin Cmd.Csv := True; Inc(i); Continue; end;
      if ParamStr(i) = '--pretty' then begin Cmd.Pretty := True; Inc(i); Continue; end;

      // ------------------------------------------------------------
      // Zeitraum-Optionen: --from/--to (nur fuer --stats fuelups)
      if ParamStr(i) = '--from' then
      begin
        if i + 1 > ParamCount then begin Cmd.ErrorMsg := 'Fehler: --from benoetigt einen Wert (YYYY-MM oder YYYY-MM-DD).'; Cmd.ErrorFocus := '--from'; Exit(False); end;
        Cmd.FromProvided := True;
        Cmd.PeriodEnabled := True;
        if not TryParseFromToValue(ParamStr(i + 1), Cmd.PeriodFromIso, Cmd.PeriodToExclIso) then
        begin
          Cmd.ErrorMsg := 'Fehler: --from hat ein ungueltiges Format. Erwartet: YYYY-MM oder YYYY-MM-DD.';
          Cmd.ErrorFocus := '--from';
          Exit(False);
        end;
        Inc(i, 2);
        Continue;
      end;

      if ParamStr(i) = '--to' then
      begin
        if i + 1 > ParamCount then begin Cmd.ErrorMsg := 'Fehler: --to benoetigt einen Wert (YYYY-MM oder YYYY-MM-DD).'; Cmd.ErrorFocus := '--to'; Exit(False); end;
        Cmd.ToProvided := True;
        Cmd.PeriodEnabled := True;

        // Achtung: --to wird als *exklusives Ende* gespeichert:
        // Wir parsen den Wert ebenfalls als Zeitraum und nehmen das ToExclIso.
        // Beispiel: --to 2025-02-28 -> ToExcl = 2025-03-01 00:00:00
        if not TryParseFromToValue(ParamStr(i + 1), TmpFromIso, TmpToExclIso) then
        begin
          Cmd.ErrorMsg := 'Fehler: --to hat ein ungueltiges Format. Erwartet: YYYY-MM oder YYYY-MM-DD.';
          Cmd.ErrorFocus := '--to';
          Exit(False);
        end;

        Cmd.PeriodToExclIso := TmpToExclIso;
        Inc(i, 2);
        Continue;
      end;

      // Seed/Demo-Optionen: --seed ist ein exklusives Hauptkommando, die uebrigen sind Zusatzparameter.
      if ParamStr(i) = '--seed' then
      begin
        if Cmd.HasCommand then
        begin
          Cmd.ErrorMsg := 'Fehler: --seed darf nicht mit anderen Kommandos kombiniert werden.';
          Cmd.ErrorFocus := '--seed';
          Exit(False);
        end;
        Cmd.Kind := ckSeed;
        Cmd.HasCommand := True;
        Inc(i);
        Continue;
      end;

      // Laufzeit-Schalter fuer Seed/Demo
      if ParamStr(i) = '--demo' then
      begin
        Cmd.UseDemoDb := True;
        Inc(i);
        Continue;
      end;

      if ParamStr(i) = '--force' then
      begin
        Cmd.SeedForce := True;
        Inc(i);
        Continue;
      end;

      // Seed-Parameter mit Zahlenwert
      if ParamStr(i) = '--stations' then
      begin
        if i + 1 > ParamCount then begin Cmd.ErrorMsg := 'Fehler: --stations benötigt eine Zahl.'; Cmd.ErrorFocus := '--stations'; Exit(False); end;
        if not TryStrToInt(ParamStr(i + 1), Cmd.SeedStations) then begin Cmd.ErrorMsg := 'Fehler: --stations benötigt eine gültige Zahl.'; Cmd.ErrorFocus := '--stations'; Exit(False); end;
        Inc(i, 2);
        Continue;
      end;

      if ParamStr(i) = '--fuelups' then
      begin
        if i + 1 > ParamCount then begin Cmd.ErrorMsg := 'Fehler: --fuelups benötigt eine Zahl.'; Cmd.ErrorFocus := '--fuelups'; Exit(False); end;
        if not TryStrToInt(ParamStr(i + 1), Cmd.SeedFuelups) then begin Cmd.ErrorMsg := 'Fehler: --fuelups benötigt eine gültige Zahl.'; Cmd.ErrorFocus := '--fuelups'; Exit(False); end;
        Inc(i, 2);
        Continue;
      end;

      if ParamStr(i) = '--seed-value' then
      begin
        if i + 1 > ParamCount then begin Cmd.ErrorMsg := 'Fehler: --seed-value benötigt eine Zahl.'; Cmd.ErrorFocus := '--seed-value'; Exit(False); end;
        if not TryStrToInt(ParamStr(i + 1), Cmd.SeedValue) then begin Cmd.ErrorMsg := 'Fehler: --seed-value benötigt eine gültige Zahl.'; Cmd.ErrorFocus := '--seed-value'; Exit(False); end;
        Inc(i, 2);
        Continue;
      end;

      if ParamStr(i) = '--show-config' then begin Cmd.ShowConfig := True; Inc(i); Continue; end;
      if ParamStr(i) = '--reset-config' then begin Cmd.ResetConfig := True; Inc(i); Continue; end;

      // DB-Optionen (2 Parameter)
      if ParamStr(i) = '--db' then
      begin
        if i + 1 > ParamCount then
        begin
          Cmd.ErrorMsg := 'Fehler: --db benötigt einen Pfad.';
          Cmd.ErrorFocus := '--db';
          Exit(False);
        end;
        Cmd.DbOverride := ParamStr(i + 1);
        Inc(i, 2);
        Continue;
      end;

      if ParamStr(i) = '--db-set' then
      begin
        if i + 1 > ParamCount then
        begin
          Cmd.ErrorMsg := 'Fehler: --db-set benötigt einen Pfad.';
          Cmd.ErrorFocus := '--db-set';
          Exit(False);
        end;
        Cmd.DbSet := ParamStr(i + 1);
        Inc(i, 2);
        Continue;
      end;

      // Hauptkommandos: --add/--list/--edit/--delete <stations|fuelups>
      if CommandKindFromFlag(ParamStr(i), TmpKind) then
      begin
        if Cmd.HasCommand then
        begin
          Cmd.ErrorMsg := 'Fehler: Genau EIN Kommando ist erlaubt.';
          Cmd.ErrorFocus := ParamStr(i);
          Exit(False);
        end;

        if i + 1 > ParamCount then
        begin
          Cmd.ErrorMsg := 'Fehler: ' + ParamStr(i) + ' benötigt eine Tabelle.';
          Cmd.ErrorFocus := ParamStr(i);
          Exit(False);
        end;

        // Tabellenart parsen (Singular/Plural)
        if not ParseTableKind(ParamStr(i + 1), Cmd.Target) then
        begin
          Cmd.ErrorMsg := 'Fehler: "' + ParamStr(i + 1) +
            '" ist keine gültige Tabelle (erlaubt: stations|fuelups).';
          Cmd.ErrorFocus := ParamStr(i);
          Exit(False);
        end;

        Cmd.Kind := TmpKind;
        Cmd.HasCommand := True;

        Inc(i, 2);
        Continue;
      end;

      // Unbekannt
      Cmd.ErrorMsg := 'Fehler: Unbekanntes Argument: ' + ParamStr(i);
      Cmd.ErrorFocus := '';
      Exit(False);
    end;

    // ----------------
    // Zentrale Validierung (Regeln)

    if (Cmd.DbOverride <> '') and (Cmd.DbSet <> '') then
    begin
      Cmd.ErrorMsg := 'Fehler: --db und --db-set können nicht zusammen verwendet werden.';
      Cmd.ErrorFocus := '--db-set';
      Exit(False);
    end;

    // --seed ist eine isolierte Aktion (Demo-DB)
    // Keine Kombination mit --db / --db-set / --demo oder anderen Commands
    if Cmd.HasCommand and (Cmd.Kind = ckSeed) then
    begin
      if (Cmd.DbOverride <> '') or (Cmd.DbSet <> '') or Cmd.UseDemoDb then
      begin
        Cmd.ErrorMsg :=
          'Fehler: --seed verwendet immer die Demo-DB und darf nicht mit ' +
          '--db, --db-set oder --demo kombiniert werden.';
        Cmd.ErrorFocus := '--seed';
        Exit(False);
      end;
    end;

    if Cmd.HasCommand and (Cmd.Kind = ckSeed) and Cmd.UseDemoDb then
    begin
      Cmd.ErrorMsg := 'Fehler: --demo ist bei --seed nicht erforderlich.';
      Cmd.ErrorFocus := '--seed';
      Exit(False);
    end;

    // Meta darf alleine stehen
    if Cmd.Help or Cmd.Version then Exit(True);

    // --db-set / show / reset sind Aktionen ohne Hauptkommando
    if Cmd.DbSet <> '' then Exit(True);
    if Cmd.ShowConfig or Cmd.ResetConfig then Exit(True);

    // sonst: Hauptkommando noetig
    if not Cmd.HasCommand then
    begin
      Cmd.ErrorMsg := 'Fehler: Kein Kommando angegeben.';
      Cmd.ErrorFocus := '';
      Exit(False);
    end;

    // Fachregel: fuelups nur add/list
    if (Cmd.Target = tkFuelups) and ((Cmd.Kind = ckEdit) or (Cmd.Kind = ckDelete)) then
    begin
      Cmd.ErrorMsg := 'Fehler: fuelups unterstützt nur add/list (append-only).';
      Cmd.ErrorFocus := '--list';
      Exit(False);
    end;

    if Cmd.HasCommand and (Cmd.Kind = ckStats) and (Cmd.Target <> tkFuelups) then
    begin
      Cmd.ErrorMsg := 'Fehler: --stats ist aktuell nur fuer fuelups verfuegbar.';
      Cmd.ErrorFocus := '--stats';
      Exit(False);
    end;

    // --json ist nur fuer "--stats fuelups" erlaubt
    if Cmd.Json then
    begin
      if not (Cmd.HasCommand and (Cmd.Kind = ckStats) and (Cmd.Target = tkFuelups)) then
      begin
        Cmd.ErrorMsg := 'Fehler: --json ist nur zusammen mit "--stats fuelups" erlaubt.';
        Cmd.ErrorFocus := '--json';
        Exit(False);
      end;
    end;

    // --csv ist nur fuer "--stats fuelups" erlaubt und exklusiv
    if Cmd.Csv then
    begin
      if not (Cmd.HasCommand and (Cmd.Kind = ckStats) and (Cmd.Target = tkFuelups)) then
      begin
        Cmd.ErrorMsg := 'Fehler: --csv ist nur zusammen mit "--stats fuelups" erlaubt.';
        Cmd.ErrorFocus := '--csv';
        Exit(False);
      end;

      if Cmd.Json then
      begin
        Cmd.ErrorMsg := 'Fehler: --csv und --json koennen nicht zusammen verwendet werden.';
        Cmd.ErrorFocus := '--csv';
        Exit(False);
      end;
    end;

    // --pretty ist nur zusammen mit --json erlaubt (und damit nur bei --stats fuelups)
    if Cmd.Pretty then
    begin
      if not Cmd.Json then
      begin
        Cmd.ErrorMsg := 'Fehler: --pretty ist nur zusammen mit --json erlaubt.';
        Cmd.ErrorFocus := '--pretty';
        Exit(False);
      end;

      if not (Cmd.HasCommand and (Cmd.Kind = ckStats) and (Cmd.Target = tkFuelups)) then
      begin
        Cmd.ErrorMsg := 'Fehler: --pretty ist nur zusammen mit "--stats fuelups --json" erlaubt.';
        Cmd.ErrorFocus := '--pretty';
        Exit(False);
      end;
    end;

    // --monthly ist nur fuer "--stats fuelups" erlaubt
    if Cmd.Monthly then
    begin
      if not (Cmd.HasCommand and (Cmd.Kind = ckStats) and (Cmd.Target = tkFuelups)) then
      begin
        Cmd.ErrorMsg := 'Fehler: --monthly ist nur zusammen mit "--stats fuelups" erlaubt.';
        Cmd.ErrorFocus := '--monthly';
        Exit(False);
      end;
    end;

    // Zeitraum-Flags nur fuer --stats fuelups erlaubt
    // ------------------------------------------------------------
    // Zeitraum-Regeln und Open-Ended-Normalisierung
    if Cmd.PeriodEnabled then
    begin
      if not (Cmd.HasCommand and (Cmd.Kind = ckStats) and (Cmd.Target = tkFuelups)) then
      begin
        Cmd.ErrorMsg := 'Fehler: --from/--to sind nur in Kombination mit --stats fuelups erlaubt.';
        Cmd.ErrorFocus := '--from';
        Exit(False);
      end;

      // Beide gesetzt: from <= to (exklusiv) pruefen
      if Cmd.FromProvided and Cmd.ToProvided then
      begin
        if Cmd.PeriodFromIso >= Cmd.PeriodToExclIso then
        begin
          Cmd.ErrorMsg := 'Fehler: Ungueltiger Zeitraum: --from muss vor --to liegen.';
          Cmd.ErrorFocus := '--from';
          Exit(False);
        end;
      end;

      // Open-ended: wird datengetrieben in Schritt 2 gefuellt.
      // Hier nur sicherstellen, dass wir *wissen*, was offen ist.
      if Cmd.FromProvided and (not Cmd.ToProvided) then
      begin
        // PeriodToExclIso ist aktuell vom --from gesetzt (naechster Tag/Monat),
        // das ist nur ein Platzhalter und wird in Schritt 2 ersetzt.
        Cmd.PeriodToExclIso := '';
      end;

      if Cmd.ToProvided and (not Cmd.FromProvided) then
      begin
        Cmd.PeriodFromIso := '';
      end;
    end;

    Result := True;
  end;

  // ----------------
  // XDG-konformer Standard-DB-Pfad
  function GetDefaultDbPath: string;
  var
    BaseDir: string;
  begin
    BaseDir := ExpandFileName(GetUserDir + '.local/share/Betankungen');
    ForceDirectories(BaseDir);
    Result := BaseDir + PathDelim + 'betankungen.db';
  end;

  // XDG-konformer Konfigurationspfad
  function GetConfigPath: string;
  var
    CfgDir: string;
  begin
    CfgDir := ExpandFileName(GetUserDir + '.config/Betankungen');
    ForceDirectories(CfgDir);
    Result := CfgDir + PathDelim + 'config.ini';
  end;

  function LoadDbPathFromConfig(out APath: string): boolean;
  var
    Ini: TIniFile;
    Cfg: string;
  begin
    APath := '';
    Cfg := GetConfigPath;
    Result := FileExists(Cfg);
    if not Result then Exit;

    Ini := TIniFile.Create(Cfg);
    try
      APath := Ini.ReadString('database', 'path', '');
      Result := APath <> '';
    finally
      Ini.Free;
    end;
  end;

  procedure SaveDbPathToConfig(const APath: string);
  var
    Ini: TIniFile;
  begin
    Ini := TIniFile.Create(GetConfigPath);
    try
      Ini.WriteString('database', 'path', APath);
    finally
      Ini.Free;
    end;
  end;

  procedure ShowConfigAndExit;
  var
    CfgPath, CfgDbPath, DefaultDb: string;
  begin
    CfgPath := GetConfigPath;
    DefaultDb := GetDefaultDbPath;

    WriteLn('--- Betankungen: Config-Status ---');
    WriteLn('Config-Datei:      ', CfgPath);
    WriteLn('Config existiert:   ', BoolToStr(FileExists(CfgPath), True));

    if LoadDbPathFromConfig(CfgDbPath) then
    begin
      CfgDbPath := ExpandFileName(CfgDbPath);
      WriteLn('Config DB-Pfad:     ', CfgDbPath);
      WriteLn('DB existiert:       ', BoolToStr(FileExists(CfgDbPath), True));
    end
    else
    begin
      WriteLn('Config DB-Pfad:     (nicht gesetzt)');
    end;

    WriteLn('Default DB-Pfad:    ', DefaultDb);
    WriteLn('Default existiert:  ', BoolToStr(FileExists(DefaultDb), True));
    WriteLn('---------------------------------');
    Halt(EXIT_OK);
  end;

  procedure ResetConfigAndExit;
  var
    CfgPath: string;
  begin
    CfgPath := GetConfigPath;

    if FileExists(CfgPath) then
    begin
      if DeleteFile(CfgPath) then
        WriteLn('Config geloescht: ', CfgPath)
      else
      begin
        WriteLn('Fehler: Konnte Config nicht loeschen: ', CfgPath);
        Halt(EXIT_CONFIG);
      end;
    end
    else
      Msg('Keine Config vorhanden (nichts zu loeschen).');

    Msg('Hinweis: Die DB-Datei wurde NICHT geloescht.');
    Halt(EXIT_OK);
  end;

  // Interaktive Abfrage des DB-Pfads (Eingabetaste = Standard)
  function AskDbPathInteractive: string;
  var
    DefaultPath: string;
    Input: string;
  begin
    DefaultPath := GetDefaultDbPath;

    WriteLn('Erster Start / keine gueltige Config gefunden.');
    WriteLn('Bitte DB-Pfad angeben oder Enter fuer Default:');
    WriteLn('  Default: ', DefaultPath);
    Write('DB-Pfad> ');
    ReadLn(Input);

    Input := Trim(Input);
    if Input = '' then
      Result := DefaultPath
    else
      Result := ExpandFileName(Input);
  end;

  // Ermittelt den endgueltigen DB-Pfad in fester Prioritaet (db-set, db, config, default, interaktiv)
  function ResolveDbPath: string;
  var
    FromCfg: string;
    DefaultPath: string;
  begin
    // --db: nur fuer diesen Lauf
    if Cmd.DbOverride <> '' then
    begin
      Result := ExpandFileName(Cmd.DbOverride);
      ForceDirectories(ExtractFileDir(Result));
      Exit;
    end;

    // Demo-DB: explizit via --demo oder implizit via --seed
    if Cmd.UseDemoDb or (Cmd.HasCommand and (Cmd.Kind = ckSeed)) then
    begin
      Result := GetDefaultDemoDbPath;
      ForceDirectories(ExtractFileDir(Result));
      Exit;
    end;

    // Konfiguration
    if LoadDbPathFromConfig(FromCfg) then
    begin
      FromCfg := ExpandFileName(FromCfg);

    // Konfiguration vorhanden, aber DB fehlt -> wie Erststart behandeln
    if FileExists(FromCfg) then
      begin
        Result := FromCfg;
        ForceDirectories(ExtractFileDir(Result));
        Exit;
      end
      else
      begin
        Msg('Hinweis: Konfiguration gefunden, aber DB-Datei existiert nicht: ' + FromCfg);
        Result := AskDbPathInteractive;
        ForceDirectories(ExtractFileDir(Result));
        SaveDbPathToConfig(Result);
        Exit;
      end;
    end;

    // Standardpfad automatisch erkennen
    DefaultPath := GetDefaultDbPath;
    if FileExists(DefaultPath) then
    begin
      Result := DefaultPath;
      ForceDirectories(ExtractFileDir(Result));
      SaveDbPathToConfig(Result);
      Exit;
    end;

    // Erststart: abfragen und Konfiguration anlegen
    Result := AskDbPathInteractive;
    ForceDirectories(ExtractFileDir(Result));
    SaveDbPathToConfig(Result);
  end;

begin
  if not BuildCommand(Cmd) then
    FailUsage(Cmd.ErrorMsg, Cmd.ErrorFocus);

  // Quiet zuerst, damit alles danach darauf reagiert
  SetQuiet(Cmd.Quiet);
  // Debug-Tabelle
  SetDebug(Cmd.Debug);
  // Trace explizit nur bei --trace
  SetTrace(Cmd.Trace);
  Dbg(
    'Cmd: Kind=' + IntToStr(Ord(Cmd.Kind)) +
    ' Target=' + IntToStr(Ord(Cmd.Target)) +
    ' Detail=' + BoolToStr(Cmd.Detail, True) +
    ' Json=' + BoolToStr(Cmd.Json, True) +
    ' Monthly=' + BoolToStr(Cmd.Monthly, True) +
    ' Csv=' + BoolToStr(Cmd.Csv, True) +
    ' Pretty=' + BoolToStr(Cmd.Pretty, True) +
    ' DbOverride=' + BoolToStr(Cmd.DbOverride <> '', True) +
    ' UseDemoDb=' + BoolToStr(Cmd.UseDemoDb, True)
  );

  if Cmd.Help then
  begin
    PrintUsage;
    Halt(EXIT_OK);
  end;

  if Cmd.Version then
  begin
    WriteLn('Betankungen ', APP_VERSION);
    Halt(EXIT_OK);
  end;

  if Cmd.DbSet <> '' then
  begin
    SaveDbPathToConfig(Cmd.DbSet);
    Msg('OK: DB-Pfad in der Konfiguration gespeichert.');
    Halt(EXIT_OK);
  end;

  if Cmd.ResetConfig then
    ResetConfigAndExit;

  if Cmd.ShowConfig then
    ShowConfigAndExit;

  if Cmd.HasCommand and (Cmd.Kind = ckSeed) then
  begin
    DbPath := GetDefaultDemoDbPath;
    Dbg('Seed: Pfad=' + DbPath);
    Dbg(
      'Seed: stations=' + IntToStr(Cmd.SeedStations) +
      ' fuelups=' + IntToStr(Cmd.SeedFuelups) +
      ' seed_value=' + IntToStr(Cmd.SeedValue) +
      ' force=' + BoolToStr(Cmd.SeedForce, True)
    );
    try
      SeedDemoDatabase(DbPath, Cmd.SeedStations, Cmd.SeedFuelups, Cmd.SeedValue, Cmd.SeedForce);
      if Cmd.Quiet then
      begin
        // Maschinenfreundlich
        WriteLn(DbPath);
      end
      else
      begin
        Msg('OK: Demo-DB erstellt/aktualisiert');
        Msg('Pfad: ' + DbPath);
        Msg('Beispiel:');
        Msg('  Betankungen --db "' + DbPath + '" --list stations');
        Msg('Oder:');
        Msg('  Betankungen --demo --list stations');
      end;
      Halt(EXIT_OK);
    except
      on E: Exception do
        FailUsage('Fehler: ' + E.Message, '--seed');
    end;
  end;

  // DB-Pfad vorbereiten (Ueberschreibung hat Prio)
  DbPath := ResolveDbPath;

  if Cmd.UseDemoDb and (not FileExists(DbPath)) then
    FailUsage('Fehler: Demo-DB nicht gefunden. Bitte zuerst "Betankungen --seed" ausführen.', '--demo');

  try
    // Datenbank sicherstellen und initialisieren
    WasCreated := EnsureDatabase(DbPath);

    // ----------------
    // Weiterleitung
    case Cmd.Target of
      tkStations:
        case Cmd.Kind of
          ckAdd: AddStationInteractive(DbPath);
          ckList: ListStations(DbPath, Cmd.Detail);
          ckEdit: EditStationInteractive(DbPath);
          ckDelete: DeleteStationInteractive(DbPath);
        else
          FailUsage('Interner Fehler: Ungültiges stations-Kommando.');
        end;

      tkFuelups:
        case Cmd.Kind of
          ckAdd: AddFuelupInteractive(DbPath);
          ckList: ListFuelups(DbPath, Cmd.Detail);
          ckStats:
            begin
              if Cmd.Csv then
                ShowFuelupStatsCsv(DbPath,
                  Cmd.PeriodEnabled,
                  Cmd.PeriodFromIso,
                  Cmd.PeriodToExclIso,
                  Cmd.FromProvided,
                  Cmd.ToProvided,
                  Cmd.Monthly)
              else if Cmd.Json then
                ShowFuelupStatsJson(DbPath,
                  Cmd.PeriodEnabled,
                  Cmd.PeriodFromIso,
                  Cmd.PeriodToExclIso,
                  Cmd.FromProvided,
                  Cmd.ToProvided,
                  Cmd.Monthly,
                  Cmd.Pretty)
              else
                ShowFuelupStats(DbPath,
                  Cmd.PeriodEnabled,
                  Cmd.PeriodFromIso,
                  Cmd.PeriodToExclIso,
                  Cmd.FromProvided,
                  Cmd.ToProvided,
                  Cmd.Monthly);
            end;
        else
          FailUsage('Interner Fehler: Ungültiges fuelups-Kommando.');
        end;
    else
      FailUsage('Interner Fehler: Unbekannter Target.');
    end;

    // ----------------
    // Statusausgabe
    // Nur melden, wenn die DB wirklich neu angelegt wurde.
    
    if (not Cmd.Debug) and WasCreated then
      Msg('Datenbank angelegt');

    // ----------------
    // Debug-Tabelle (nur bei Debug)
    if Cmd.Debug and (not Cmd.Quiet) then
    begin
      WriteLn('');
      DbgSep;
      DbgRow('Key', 'Value');
      DbgSep;
      DbgRow('DB-Pfad', ExpandFileName(DbPath));
      DbgRow('schema_version', ReadMetaValue(DbPath, 'schema_version'));
      DbgRow('app_name', ReadMetaValue(DbPath, 'app_name'));
      DbgRow('db_created_at', ReadMetaValue(DbPath, 'db_created_at'));
      DbgRow('db_last_run', ReadMetaValue(DbPath, 'db_last_run'));
      DbgRow('odometer_start_km', ReadMetaValue(DbPath, 'odometer_start_km'));
      DbgRow('odometer_start_date', ReadMetaValue(DbPath, 'odometer_start_date'));
      DbgSep;
    end;

  except
    on E: Exception do
    begin
      WriteLn('Fehler: ', E.Message);
      Halt(EXIT_UNEXPECTED);
    end;
  end;
end.
