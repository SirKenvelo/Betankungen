{
  u_db_init.pas
  ---------------------------------------------------------------------------
  UPDATED: 2026-02-07
  AUTHOR : Christof Kempinski
  Datenbank-Bootstrapper und Schema-Verwaltung für SQLite.

  Verantwortlichkeiten:
  - Automatisches Provisioning: Erstellt die SQLite-Datei bei Erststart.
  - Idempotentes Schema-Design: Stellt Tabellen, Indizes und Trigger bereit, 
    ohne bestehende Daten zu gefährden (Verwendung von 'IF NOT EXISTS').
  - Metadaten-Management: Initialisiert und aktualisiert technische Kennzahlen 
    (Schema-Versionen, Start-KM-Stände, Zeitstempel) in der 'meta'-Tabelle.
  - Datenintegrität: Erzwingt Constraints (FK, CHECK) und nutzt atomare 
    Transaktionen für den gesamten Initialisierungsprozess.

  Design-Entscheidungen:
  - Transaktionssicherheit: Alles oder Nichts. Schlägt ein Teil des Schemas 
    fehl, wird die gesamte DB in den Vorzustand versetzt (Rollback).
  - Robustheit: Explizite Trennung von technischem Fehlerhandling (try-except) 
    und Ressourcen-Bereinigung (try-finally).
  - Skalierbarkeit: Vorbereitet für zukünftige Migrations-Logik durch 
    zentrale Speicherung der 'schema_version'.

  Hinweis: Die Unit nutzt die SQLDB-Komponenten von Free Pascal (TSQLite3Connection).

  Schema-Historie:
  v1: Basis-Metadaten (meta-Tabelle)
  v2: Stammdaten für Tankstellen (stations)
  v3: Transaktionsdaten für Betankungen (fuelups) inkl. Start-KM Logik

  Hinweis: Bei Schema-Änderungen bitte die 'schema_version' in der 
  EnsureDatabase-Prozedur UND hier im Header inkrementieren.
  ---------------------------------------------------------------------------
}
unit u_db_init;

{$mode objfpc}{$H+}

interface

// ----------------
// Stellt sicher, dass die DB existiert und das Schema aktuell ist.
// Rueckgabewert: True, wenn die DB-Datei neu angelegt wurde.
function EnsureDatabase(const DbPath: string): boolean;

// Liest einen Wert aus der meta-Tabelle (technische Key-Value Metadaten).
function ReadMetaValue(const DbPath, AKey: string): string;

implementation

uses
  Classes, SysUtils, SQLite3Conn, SQLDB, u_log;

// ----------------
// Stellt sicher, dass die DB existiert und das Schema aktuell ist.
// Rueckgabewert: True, wenn die DB-Datei neu angelegt wurde.
function EnsureDatabase(const DbPath: string): boolean;
var
  CreatedNow: boolean;
  Conn: TSQLite3Connection;
  Tran: TSQLTransaction;
  Q: TSQLQuery;
begin
  // Existiert die Datei bereits? (Conn.Open legt sie an, falls nicht vorhanden)
  CreatedNow := not FileExists(DbPath);

  Dbg('EnsureDatabase: ' + ExpandFileName(DbPath));
  Dbg('CreatedNow=' + BoolToStr(CreatedNow, True));

  Conn := TSQLite3Connection.Create(nil);
  Tran := TSQLTransaction.Create(nil);
  Q := TSQLQuery.Create(nil);

  try
    try
      // Verbindung und Transaktion verdrahten
      Conn.DatabaseName := DbPath;
      Conn.Transaction := Tran;
      Q.DataBase := Conn;
      Q.Transaction := Tran;

      // Verbindung oeffnen und Transaktion starten
      Dbg('Opening connection...');
      Conn.Open;
      Dbg('Connection open.');

      Dbg('Starting transaction...');
      // Startet nur, wenn nicht schon aktiv (SQLDB kann auto-starten)
      if not Tran.Active then
        Tran.StartTransaction;

      // Technische Metadaten-Tabelle
      Dbg('Ensuring meta table...');
      Q.SQL.Text :=
        'CREATE TABLE IF NOT EXISTS meta (' + '  key   TEXT PRIMARY KEY,' +
        '  value TEXT' + ');';
      Q.ExecSQL;

      // Schema-Version setzen (fuer spaetere Migrationen)
      Q.SQL.Text := 'INSERT OR REPLACE INTO meta(key, value) VALUES(:k, :v);';
      Q.Params.ParamByName('k').AsString := 'schema_version';
      Q.Params.ParamByName('v').AsString := '3';
      Q.ExecSQL;

      // App-Name (rein informativ)
      Q.SQL.Text := 'INSERT OR REPLACE INTO meta(key, value) VALUES(:k, :v);';
      Q.Params.ParamByName('k').AsString := 'app_name';
      Q.Params.ParamByName('v').AsString := 'Betankungen';
      Q.ExecSQL;

      // Anfangs-Kilometerstand fuer spaetere Berechnungen
      // Nicht veraenderbar
      Q.SQL.Text := 'INSERT OR IGNORE INTO meta(key, value) ' + 
                    'VALUES("odometer_start_km", "134607");';
      Q.ExecSQL;

      // Datum des Start-Kilometerstands
      // Nicht veraenderbar
      Q.SQL.Text := 'INSERT OR IGNORE INTO meta(key, value) ' +
                    'VALUES("odometer_start_date", "2026-01-01");';
      Q.ExecSQL;

      // Erst-Erstellungsdatum nur beim ersten Anlegen
      if CreatedNow then
      begin
        Q.SQL.Text :=
          'INSERT OR IGNORE INTO meta(key, value) ' +
          'VALUES("db_created_at", date("now"));';
        Q.ExecSQL;
      end;

      // Letzte Ausfuehrung immer aktualisieren
      Q.SQL.Text :=
        'INSERT OR REPLACE INTO meta(key, value) ' +
        'VALUES("db_last_run", datetime("now"));';
      Q.ExecSQL;

      // Fach-Tabelle: stations
      Dbg('Ensuring stations table...');
      Q.SQL.Text :=
        'CREATE TABLE IF NOT EXISTS stations (' +
        '  id         INTEGER PRIMARY KEY,' + 
        '  brand      TEXT NOT NULL,' +
        '  street     TEXT NOT NULL,' + 
        '  house_no   TEXT NOT NULL,' +
        '  zip        TEXT NOT NULL,' + 
        '  city       TEXT NOT NULL,' +
        '  phone      TEXT,' + 
        '  owner      TEXT,' +
        '  created_at TEXT NOT NULL DEFAULT (datetime(''now'')),' +
        '  updated_at TEXT' + 
        ');';
      Q.ExecSQL;

      // Indizes und Unique-Constraint fuer Duplikate (Adresse)
      Dbg('Ensuring stations indexes...');

      Q.SQL.Text :=
        'CREATE UNIQUE INDEX IF NOT EXISTS idx_stations_unique_location ' +
        'ON stations(street, house_no, zip, city);';
      Q.ExecSQL;

      Q.SQL.Text :=
        'CREATE INDEX IF NOT EXISTS idx_stations_brand ON stations(brand);';
      Q.ExecSQL;

      Q.SQL.Text :=
        'CREATE INDEX IF NOT EXISTS idx_stations_city ON stations(city);';
      Q.ExecSQL;

      // Fach-Tabelle: fuelups
      Dbg('Ensuring fuelups table...');
      Q.SQL.Text :=
        'CREATE TABLE IF NOT EXISTS fuelups (' +
        '  id         INTEGER PRIMARY KEY,' +
        '  station_id                  INTEGER NOT NULL,' +
        '  fueled_at                   TEXT    NOT NULL,' +
        '  odometer_km                 INTEGER NOT NULL,' +
        '  liters_ml                   INTEGER NOT NULL,' +
        '  total_cents                 INTEGER NOT NULL,' +
        '  price_per_liter_milli_eur   INTEGER NOT NULL,' +
        '  is_full_tank                INTEGER NOT NULL DEFAULT 0,' +
        '  fuel_type                   TEXT,' +
        '  payment_type                TEXT,' +
        '  pump_no                     TEXT,' +
        '  note                        TEXT,' +
        '  created_at                  TEXT NOT NULL DEFAULT (datetime(''now'')),' +
        '  updated_at                  TEXT,' +
        '  FOREIGN KEY(station_id) REFERENCES stations(id) ON DELETE RESTRICT,' +
        '  CHECK (odometer_km > 0),' +
        '  CHECK (liters_ml > 0),' +
        '  CHECK (total_cents >= 0),' +
        '  CHECK (price_per_liter_milli_eur >= 0),' +
        '  CHECK (is_full_tank IN (0,1))' +
        ');';
      Q.ExecSQL;

      // Indizes fuer typische Abfragen
      Dbg('Ensuring fuelups indexes...');
      
      Q.SQL.Text := 
        'CREATE INDEX IF NOT EXISTS idx_fuelups_station_id   ON fuelups(station_id);';
      Q.ExecSQL;

      Q.SQL.Text :=  
        'CREATE INDEX IF NOT EXISTS idx_fuelups_fueled_at    ON fuelups(fueled_at);';
      Q.ExecSQL;

      Q.SQL.Text :=  
        'CREATE INDEX IF NOT EXISTS idx_fuelups_odometer_km  ON fuelups(odometer_km);';
      Q.ExecSQL;

      // Duplikat-Schutz (gleiche Station, Zeit und Kilometerstand)
      Q.SQL.Text := 
        'CREATE UNIQUE INDEX IF NOT EXISTS idx_fuelups_unique ' +
        'ON fuelups(station_id, fueled_at, odometer_km);';      
      Q.ExecSQL;

      // Trigger fuer automatisches updated_at
      Dbg('Ensuring fuelups triggers...');
      Q.SQL.Text := 
        'CREATE TRIGGER IF NOT EXISTS trg_fuelups_set_updated_at ' +
        'AFTER UPDATE ON fuelups ' +
        'FOR EACH ROW ' +
        'WHEN NEW.updated_at IS OLD.updated_at OR NEW.updated_at IS NULL ' +
        'BEGIN ' +
        '  UPDATE fuelups ' +
        '  SET updated_at = datetime(''now'') ' + 
        '  WHERE id = NEW.id; ' +
        'END; ';
      Q.ExecSQL;

      // Transaktion abschliessen
      Dbg('Commit...');
      Tran.Commit;
      Dbg('Commit: OK');

      Result := CreatedNow;

    except
      on E: Exception do
      begin
        Dbg('Error: ' + E.Message);
        if Assigned(Tran) and Tran.Active then
        begin
          Dbg('Rollback...');
          Tran.Rollback;
        end;
        raise Exception.Create('DB-Init fehlgeschlagen: ' + E.Message);
      end;
    end;
  finally
    Q.Free;
    Tran.Free;
    Conn.Free;
  end;
end;

// ----------------
// Liest einen Wert aus der meta-Tabelle (technische Key-Value Metadaten).
function ReadMetaValue(const DbPath, AKey: string): string;
var
  Conn: TSQLite3Connection;
  Tran: TSQLTransaction;
  Q: TSQLQuery;
begin
  Result := '';

  Conn := TSQLite3Connection.Create(nil);
  Tran := TSQLTransaction.Create(nil);
  Q := TSQLQuery.Create(nil);

  try
    try
      Conn.DatabaseName := DbPath;
      Conn.Transaction := Tran;
      Q.DataBase := Conn;
      Q.Transaction := Tran;

      Conn.Open;
      // Startet nur, wenn nicht schon aktiv (SQLDB kann auto-starten)
      if not Tran.Active then
        Tran.StartTransaction;

      Q.SQL.Text := 'SELECT value FROM meta WHERE key = :k;';
      Q.Params.ParamByName('k').AsString := AKey;
      Q.Open;

      if not Q.EOF then
        Result := Q.Fields[0].AsString;

      Q.Close;
      Tran.Commit;

    except
      on E: Exception do
      begin
        if Assigned(Tran) and Tran.Active then
          Tran.Rollback;
        raise Exception.Create('ReadMetaValue fehlgeschlagen (' +
          AKey + '): ' + E.Message);
      end;
    end;
  finally
    Q.Free;
    Tran.Free;
    Conn.Free;
  end;
end;

end.