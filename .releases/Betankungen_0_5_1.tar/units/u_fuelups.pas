{
  u_fuelups.pas
  ---------------------------------------------------------------------------
  UPDATED: 2026-02-03
  AUTHOR : Christof Kempinski
  Modul für die Geschäftslogik und Darstellung von Betankungsvorgängen.

  Zweck:
  - Steuerung des Erfassungsprozesses (Benutzereingabe -> Validierung -> DB).
  - Aufbereitung und Anzeige der Tankhistorie unter Nutzung von 'u_fmt'.
  - Sicherstellung der Datenintegrität (Foreign Keys, Pflichtfelder).

  Design-Prinzipien:
  - Datentransfer: Nutzt 'TFuelupInput' Records zur Entkopplung von UI und DB.
  - Präzision: Verwendung von skalierten Ganzzahlen (Cents, Milli-Liter) zur 
    Vermeidung von Rundungsfehlern bei der Eingabe (via 'u_db_common').
  - UI-Konsistenz: Delegiert alle Rahmen- und Tabellenformate an 'u_fmt'.

  Hinweis: Erfordert eine aktive SQLite-Verbindung mit PRAGMA foreign_keys = ON.
  ---------------------------------------------------------------------------
}

unit u_fuelups;

{$mode objfpc}{$H+}

interface

uses
  Classes, SysUtils, StrUtils, SQLDB, SQLite3Conn;

// ----------------
// Oeffentliche Schnittstelle

// Startet den interaktiven Dialog zum Hinzufuegen einer Betankung
procedure AddFuelupInteractive(const DbPath: string);

// Zeigt die Liste aller Betankungen an (Detailed steuert Zusatzinfos)
procedure ListFuelups(const DbPath: string; Detailed: boolean);

implementation

uses
  u_db_common,
  u_fmt,
  u_log;

type
  // ----------------
  // Datenstrukturen

  // Datensatz zur temporaeren Speicherung der Benutzereingaben
  TFuelupInput = record
    StationId: integer;
    FueledAt: string;     // Format: "YYYY-MM-DD HH:MM:SS"
    OdometerKm: integer;
    LitersMl: int64;      // Menge in Millilitern
    TotalCents: int64;    // Gesamtbetrag in Cents
    PricePerLiterMilliEur: int64; // Preis/Liter in Milli-Cents
    IsFullTank: boolean;
    FuelType: string;
    PaymentType: string;
    PumpNo: string;
    Note: string;
  end;

// ----------------
// Interne Hilfsfunktion: Listet alle verfuegbaren Tankstellen zur Auswahl auf
procedure PrintStations(Q: TSQLQuery);
begin
  Q.Close;
  Q.SQL.Text :=
    'SELECT id, brand, city, street, house_no ' +
    'FROM stations ' +
    'ORDER BY brand, city, street, house_no;';
  Q.Open;

  if Q.EOF then
  begin
    WriteLn('Keine Tankstellen vorhanden. Bitte zuerst --add stations ausführen.');
    Exit;
  end;

  WriteLn;
  WriteLn('Verfügbare Tankstellen:');
  WriteLn(DupeString('-', 50));

  while not Q.EOF do
  begin
    WriteLn(
      Format('%3s: %s [%s, %s %s]', [
        Q.FieldByName('id').AsString,
        Q.FieldByName('brand').AsString,
        Q.FieldByName('city').AsString,
        Q.FieldByName('street').AsString,
        Q.FieldByName('house_no').AsString
      ])
    );
    Q.Next;
  end;
  WriteLn;
end;

// Prüft, ob eine eingegebene Station-ID in der DB existiert
function StationExists(Q: TSQLQuery; const AStationId: Integer): boolean;
begin
  Q.Close;
  Q.SQL.Text := 'SELECT 1 FROM stations WHERE id = :id LIMIT 1;';
  Q.ParamByName('id').AsInteger := AStationId;
  Q.Open;
  Result := not Q.EOF;
end;

// Interaktive Auswahl der Tankstelle mit Validierungsschleife
function SelectStationIdInteractive(Q: TSQLQuery): Integer;
var
  S: string;
  Id: Integer;
begin
  PrintStations(Q);

  while True do
  begin
    Write('Stations-ID (oder "l"=Liste, "q"=Abbruch): ');
    ReadLn(S);
    S := Trim(LowerCase(S));

    if (S = 'q') or (S = 'quit') then
      raise Exception.Create('Abbruch durch Benutzer.');

    if (S = 'l') or (S = 'list') then
    begin
      PrintStations(Q);
      Continue;
    end;

    if not TryStrToInt(S, Id) then
    begin
      WriteLn('Fehler: Bitte eine gültige Zahl eingeben.');
      Continue;
    end;

    if (Id <= 0) or not StationExists(Q, Id) then
    begin
      WriteLn('Fehler: Ungueltige Stations-ID. ("l" fuer Liste)');
      Continue;
    end;

    Result := Id;
    Exit;
  end;
end;

// Hauptprozedur zum Erfassen neuer Daten
procedure AddFuelupInteractive(const DbPath: string);
var
  Conn: TSQLite3Connection;
  Tran: TSQLTransaction;
  Q, QS: TSQLQuery;
  Inp: TFuelupInput;
  S: string;

  // Setzt optionale String-Parameter (leerer String wird zu NULL)
  procedure SetOptStr(const P, V: string);
  begin
    if V = '' then
      Q.ParamByName(P).Clear
    else
      Q.ParamByName(P).AsString := V;
  end;
  
  // Rollback und Fehler weiterreichen
  procedure Fail(const Prefix: string; E: Exception);
  begin
    if Tran.Active then
      Tran.Rollback;
    raise Exception.Create(Prefix + E.Message);
  end;
begin
  WriteLn('--- Neue Betankung erfassen ---');

  Conn := TSQLite3Connection.Create(nil);
  Tran := TSQLTransaction.Create(nil);
  Q := TSQLQuery.Create(nil);
  QS := TSQLQuery.Create(nil);

  try
    Conn.DatabaseName := DbPath;
    Conn.Transaction := Tran;
    Q.DataBase := Conn;
    Q.Transaction := Tran;
    QS.DataBase := Conn;
    QS.Transaction := Tran;

    Conn.Open;
    Conn.ExecuteDirect('PRAGMA foreign_keys = ON;');
    // Startet nur, wenn nicht schon aktiv (SQLDB kann auto-starten)
    if not Tran.Active then
      Tran.StartTransaction;
    
    try
      Inp.StationId := SelectStationIdInteractive(QS);
      Inp.FueledAt := AskRequired('Datum+Uhrzeit (YYYY-MM-DD HH:MM:SS): ');

      S := AskRequired('Kilometerstand (km): ');
      if not TryStrToInt(S, Inp.OdometerKm) then
        raise Exception.Create('Ungültiger Kilometerstand.');

      // Erfassung der skalierten Ganzzahl-Werte
      Inp.TotalCents := AskAndParseInt64(
        'Gesamtpreis (EUR, z.B. 50,01): ',
        @ParseEuroToCents, @FmtEuroFromCents, 'Gesamtpreis', False
      );

      Inp.LitersMl := AskAndParseInt64(
        'Getankte Menge (Liter, z.B. 28,76): ',
        @ParseLitersToMl, @FmtLiterFromMl, 'Liter', False
      );

      Inp.PricePerLiterMilliEur := AskAndParseInt64(
        'Preis pro Liter (EUR/L, z.B. 1,739): ',
        @ParseEurPerLiterToMilli, @FmtEurPerLiterFromMilli, 'Preis/L', False
      );

      Inp.IsFullTank := AskYesNo('Vollgetankt?', True);

      Inp.FuelType    := AskOptional('Spritart (optional, z.B. E10): ');
      Inp.PaymentType := AskOptional('Bezahlart (optional, z.B. EC): ');
      Inp.PumpNo      := AskOptional('Zapfsäule (optional): ');
      Inp.Note        := AskOptional('Notiz (optional): ');

      Q.SQL.Text :=
        'INSERT INTO fuelups(' +
        '  station_id, fueled_at, odometer_km, liters_ml, total_cents, price_per_liter_milli_eur,' +
        '  is_full_tank, fuel_type, payment_type, pump_no, note' +
        ') VALUES(' +
        '  :station_id, :fueled_at, :odometer_km, :liters_ml, :total_cents, :ppl_milli,' +
        '  :is_full_tank, :fuel_type, :payment_type, :pump_no, :note' +
        ');';

      Q.ParamByName('station_id').AsInteger := Inp.StationId;
      Q.ParamByName('fueled_at').AsString   := Inp.FueledAt;
      Q.ParamByName('odometer_km').AsInteger := Inp.OdometerKm;
      Q.ParamByName('liters_ml').AsLargeInt := Inp.LitersMl;
      Q.ParamByName('total_cents').AsLargeInt := Inp.TotalCents;
      Q.ParamByName('ppl_milli').AsLargeInt := Inp.PricePerLiterMilliEur;
      Q.ParamByName('is_full_tank').AsInteger := Ord(Inp.IsFullTank);

      SetOptStr('fuel_type', Inp.FuelType);
      SetOptStr('payment_type', Inp.PaymentType);
      SetOptStr('pump_no', Inp.PumpNo);
      SetOptStr('note', Inp.Note);

      Dbg('AddFuelup: station_id=' + IntToStr(Inp.StationId) +
        ' full=' + BoolToStr(Inp.IsFullTank, True));
      Q.ExecSQL;
      Tran.Commit;
      WriteLn('OK: Betankung erfolgreich gespeichert.');

    except
      on E: Exception do
        Fail('AddFuelup fehlgeschlagen: ', E);
    end;
  finally
    QS.Free; Q.Free; Tran.Free; Conn.Free;
  end;
end;

// Listet die Tankhistorie tabellarisch auf
procedure ListFuelups(const DbPath: string; Detailed: boolean);
var
  Conn: TSQLite3Connection;
  Tran: TSQLTransaction;
  Q: TSQLQuery;
  IsFirstRow: boolean;
  RowCount: integer;

  // Rollback und Fehler weiterreichen
  procedure Fail(const Prefix: string; E: Exception);
  begin
    if Tran.Active then
      Tran.Rollback;
    raise Exception.Create(Prefix + E.Message);
  end;
begin
  Dbg('ListFuelups: detailed=' + BoolToStr(Detailed, True));
  Conn := TSQLite3Connection.Create(nil);
  Tran := TSQLTransaction.Create(nil);
  Q := TSQLQuery.Create(nil);
  try
    Conn.DatabaseName := DbPath;
    Conn.Transaction := Tran;
    Q.DataBase := Conn;
    Q.Transaction := Tran;

    Conn.Open;
    Conn.ExecuteDirect('PRAGMA foreign_keys = ON;');
    if not Tran.Active then
      Tran.StartTransaction;

    try
      Q.SQL.Text :=
        'SELECT f.id, f.fueled_at, f.odometer_km, f.liters_ml, f.total_cents, ' +
        '       f.price_per_liter_milli_eur, f.is_full_tank, ' +
        '       COALESCE(f.fuel_type, '''') AS fuel_type, ' +
        '       COALESCE(f.payment_type, '''') AS payment_type, ' +
        '       COALESCE(f.pump_no, '''') AS pump_no, ' +
        '       COALESCE(f.note, '''') AS note, ' +
        '       s.brand, s.city, s.street, s.house_no ' +
        'FROM fuelups f ' +
        'JOIN stations s ON s.id = f.station_id ' +
        'ORDER BY f.fueled_at DESC, f.id DESC;';
      Q.Open;

      if Q.EOF then
      begin
        WriteLn('Keine Betankungsdaten gefunden.');
        if Tran.Active then
          Tran.Commit;
        Exit;
      end;

      PrintFuelupHeader;

      IsFirstRow := True;
      RowCount := 0;
      while not Q.EOF do
      begin
        Inc(RowCount);
        if not IsFirstRow then
          if Detailed then
            // Duenne Linie fuer den Detail-Block-Trenner
            PrintFuelupSeparator
          else
            // Dicke Linie fuer den Standard-Zeilentrenner
            PrintFuelupSeparatorDouble;

        PrintFuelupRow(
          Q.FieldByName('id').AsInteger,
          Q.FieldByName('fueled_at').AsString,
          Q.FieldByName('odometer_km').AsLargeInt,
          Q.FieldByName('liters_ml').AsLargeInt,
          Q.FieldByName('price_per_liter_milli_eur').AsLargeInt,
          Q.FieldByName('total_cents').AsLargeInt,
          Q.FieldByName('brand').AsString + ' (' + Q.FieldByName('city').AsString + ')'
        );
    
        if Detailed then
        begin
          PrintFuelupDetail(
            Q.FieldByName('is_full_tank').AsInteger = 1,
            Q.FieldByName('fuel_type').AsString,
            Q.FieldByName('payment_type').AsString,
            Q.FieldByName('pump_no').AsString,
            Q.FieldByName('note').AsString,
            Q.FieldByName('street').AsString + ' ' + Q.FieldByName('house_no').AsString + ', ' + Q.FieldByName('city').AsString
          );
        end;
        
        IsFirstRow := False;
        Q.Next;
      end;

      PrintFuelupFooter(Detailed);
      Dbg('ListFuelups: rows=' + IntToStr(RowCount));
      Tran.Commit;
    except
      on E: Exception do
        Fail('Fehler beim Laden der Liste: ', E);
    end;
  finally
    Q.Free; Tran.Free; Conn.Free;
  end;
end;

end.