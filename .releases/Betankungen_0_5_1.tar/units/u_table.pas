{
  u_table.pas
  ---------------------------------------------------------------------------
  UPDATED: 2026-02-04
  AUTHOR : Christof Kempinski
  Dienstprogramme für die textbasierte Datenformatierung auf der Konsole.

  Zweck:
  - Zentralisierung von Padding-, Kürzung- und Ausrichtungslogik (Layout-Helfer).
  - Gewährleistung einer konsistenten, spaltenbasierten Darstellung im Terminal.
  - Abstrahierung der Darstellungslogik von der Fachlogik (Separation of Concerns).
  - Bereitstellung eines leichten Tabellen-Renderers (TTable) für kompakte Ausgaben.

  Design-Entscheidungen:
  - Visualisierung: Implementiert ein robustes Kürzungsmuster (Cut), das zu 
    breite Inhalte optisch ansprechend mit einem Ellipsen-Zeichen ('…') versieht.
  - Minimalismus: Die Unit enthält keine Steuerung der Bildschirmfarben oder 
    des globalen Layouts (dies bleibt 'u_log' bzw. den aufrufenden Units 
    vorbehalten).
  - Wiederverwendbarkeit: Bietet generische Helferfunktionen, die unabhängig von 
    spezifischen Spaltenbreiten (wie COL_ID oder COL_BRAND) arbeiten.

  Verwendung:
  - `PadR`: Richtet Text linksbündig aus (rechts mit Leerzeichen aufgefüllt).
  - `PadL`: Richtet Text rechtsbündig aus (links mit Leerzeichen aufgefüllt).
  ---------------------------------------------------------------------------
}

unit u_table;

{$mode objfpc}{$H+}

interface

uses SysUtils,
     Math;

function PadR(const S: string; W: Integer): string;
function PadL(const S: string; W: Integer): string;
function Cut(const S: string; W: Integer): string;

type
  TTextAlign = (taLeft, taRight);

  TTable = class
  private
    type
      TCol = record
        Title: string;
        Align: TTextAlign;
        Width: Integer;
      end;
      TRowKind = (rkRow, rkSep);
      TRow = record
        Kind: TRowKind;
        Cells: array of string;
      end;
    var
      FCols: array of TCol;
      FRows: array of TRow;
    procedure EnsureColCount(const Count: Integer);
    procedure UpdateWidths(const Cells: array of string);
    function PadCell(const S: string; W: Integer; Align: TTextAlign): string;
    function BuildLine(const SepChar: Char): string;
  public
    procedure AddCol(const Title: string; const Align: TTextAlign);
    procedure AddRow(const Cells: array of string);
    procedure AddSep;
    procedure Write;
  end;

implementation

function Cut(const S: string; W: Integer): string;
begin
  if W <= 0 then Exit('');
  if Length(S) <= W then Exit(S);
  if W <= 1 then Exit(Copy(S, 1, W));
  Result := Copy(S, 1, W-1) + '…';
end;

function PadR(const S: string; W: Integer): string;
var T: string;
begin
  T := Cut(S, W);
  Result := T + StringOfChar(' ', Max(0, W - Length(T)));
end;

function PadL(const S: string; W: Integer): string;
var T: string;
begin
  T := Cut(S, W);
  Result := StringOfChar(' ', Max(0, W - Length(T))) + T;
end;

{ TTable }

procedure TTable.EnsureColCount(const Count: Integer);
var
  I: Integer;
begin
  if Length(FCols) >= Count then Exit;
  SetLength(FCols, Count);
  for I := 0 to High(FCols) do
    if FCols[I].Width = 0 then
      FCols[I].Width := Length(FCols[I].Title);
end;

procedure TTable.UpdateWidths(const Cells: array of string);
var
  I: Integer;
  L: Integer;
begin
  for I := 0 to High(Cells) do
  begin
    L := Length(Cells[I]);
    if L > FCols[I].Width then
      FCols[I].Width := L;
  end;
end;

function TTable.PadCell(const S: string; W: Integer; Align: TTextAlign): string;
begin
  if Align = taRight then
    Result := PadL(S, W)
  else
    Result := PadR(S, W);
end;

function TTable.BuildLine(const SepChar: Char): string;
var
  I: Integer;
begin
  Result := '+';
  for I := 0 to High(FCols) do
    Result := Result + StringOfChar(SepChar, FCols[I].Width + 2) + '+';
end;

procedure TTable.AddCol(const Title: string; const Align: TTextAlign);
var
  N: Integer;
begin
  N := Length(FCols);
  SetLength(FCols, N + 1);
  FCols[N].Title := Title;
  FCols[N].Align := Align;
  FCols[N].Width := Length(Title);
end;

procedure TTable.AddRow(const Cells: array of string);
var
  R: TRow;
  I, ColCount: Integer;
begin
  ColCount := Length(FCols);
  EnsureColCount(ColCount);
  R.Kind := rkRow;
  SetLength(R.Cells, ColCount);
  for I := 0 to ColCount - 1 do
  begin
    if I <= High(Cells) then
      R.Cells[I] := Cells[I]
    else
      R.Cells[I] := '';
  end;
  UpdateWidths(R.Cells);
  SetLength(FRows, Length(FRows) + 1);
  FRows[High(FRows)] := R;
end;

procedure TTable.AddSep;
var
  R: TRow;
begin
  R.Kind := rkSep;
  SetLength(R.Cells, 0);
  SetLength(FRows, Length(FRows) + 1);
  FRows[High(FRows)] := R;
end;

procedure TTable.Write;
var
  I, J: Integer;
  Line: string;
  R: TRow;
begin
  if Length(FCols) = 0 then Exit;

  Line := BuildLine('=');
  WriteLn(Line);

  Line := '|';
  for I := 0 to High(FCols) do
    Line := Line + ' ' + PadCell(FCols[I].Title, FCols[I].Width, FCols[I].Align) + ' |';
  WriteLn(Line);

  Line := BuildLine('-');
  WriteLn(Line);

  for I := 0 to High(FRows) do
  begin
    R := FRows[I];
    if R.Kind = rkSep then
    begin
      Line := BuildLine('=');
      WriteLn(Line);
      Continue;
    end;

    Line := '|';
    for J := 0 to High(FCols) do
      Line := Line + ' ' + PadCell(R.Cells[J], FCols[J].Width, FCols[J].Align) + ' |';
    WriteLn(Line);
  end;

  Line := BuildLine('-');
  WriteLn(Line);
end;

end.