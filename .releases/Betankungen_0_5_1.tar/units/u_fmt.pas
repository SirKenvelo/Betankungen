{
  u_fmt.pas
  ---------------------------------------------------------------------------
  UPDATED: 2026-02-10
  AUTHOR : Christof Kempinski
  Zentrales Modul für Formatierung und Tabellen-Darstellung (CLI-UI).

  Zweck:
  1. Daten-Formatierung: 
     - Kapselung der Umrechnung von Ganzzahl-Basiseinheiten (Cents, Milliliter)
       in standardisierte Anzeige-Strings (ISO-konform).
     - Gewährleistung konsistenter Rundung und Vermeidung von "Magic Numbers".
  2. UI-Darstellung:
     - Bereitstellung einer konsistenten Tabellen-Optik für Terminal-Ausgaben.
     - Zentrales Management von Spaltenbreiten und Unicode-Rahmenelementen.
  3. CSV-Helper:
     - Strikte, maschinenlesbare Tokens/Zeilen ohne Escaping (bewusst simpel).

  Konventionen:
  - Eingabewerte für Berechnungen sind Int64 (Vermeidung von Floating-Point-
    Ungenauigkeiten in der Geschäftslogik).
  - Die Tabellenbreite wird dynamisch anhand der Spalten-Konstanten berechnet.
  - Verwendet UTF-8 Box-Drawing-Characters für die Darstellung.

  Hinweis: Dezimaltrennzeichen ist fest auf ',' gesetzt (unabhängig von Locale).
  ---------------------------------------------------------------------------
}

unit u_fmt;

{$mode objfpc}{$H+}

interface

uses SysUtils, u_table, StrUtils;

// ----------------
// Formatierungsfunktionen fuer die Geschaeftslogik

function FmtEuroFromCents(const V: Int64): string;        // Wandelt Cents in einen EUR-String
function FmtLiterFromMl(const V: Int64): string;          // Wandelt ml in einen Liter-String
function FmtEurPerLiterFromMilli(const V: Int64): string; // Wandelt Milli-Cent in einen EUR/L-String
function FmtBoolYN(const V: Integer): string;             // Wandelt Bool in "N"/"Y"

// ----------------
// CSV Helper (maschinenlesbar, strikt & simpel)

// Validiert Token fuer CSV (keine Kommas/Quotes/CRLF), gibt Token unveraendert zurueck
function CsvTokenStrict(const S: string): string;

// Baut eine CSV-Zeile aus Strings (Strings muessen bereits safe sein, z.B. via CsvTokenStrict)
function CsvJoin(const Values: array of string): string;

// Baut eine CSV-Zeile aus Int64 (reines IntToStr + Komma-Separierung)
function CsvJoinInt64(const Values: array of Int64): string;

// ----------------
// Prozeduren fuer die Tabellen-Ausgabe (CLI)

// Zeichnet den oberen Rahmen und die Spaltenueberschriften
procedure PrintFuelupHeader;

// Zeichnet den unteren Rahmen (Simple=True fuer durchgehende Linie ohne Spaltentrenner)
procedure PrintFuelupFooter(Simple: Boolean = False);

// Zeichnet eine einfache Trennlinie innerhalb der Tabelle
procedure PrintFuelupSeparator;

// Zeichnet eine dicke (doppelte) Trennlinie (fuer Standardansicht)
procedure PrintFuelupSeparatorDouble;

// Gibt eine einzelne Datensatz-Zeile formatiert aus
procedure PrintFuelupRow(
  const AId: Integer; 
  const AFueledAt: string; 
  const AOdometerKm: Int64; 
  const ALitersMl: Int64; 
  const APriceMilli: Int64; 
  const ATotalCents: Int64; 
  const AStation: string
);

// Gibt Detail-Informationen (Notizen, Adresse) unter einer Zeile aus
procedure PrintFuelupDetail(
  const AIsFull: Boolean; 
  const AFuelType, APayment, APump, ANote, AAddress: string
);

// ----------------
// Farbkodierung

const
  // ANSI Escape Codes fuer Farben
  C_RESET  = #27 + '[0m';
  C_YELLOW = #27 + '[33m';
  C_CYAN   = #27 + '[36m';

const
  // Definition der Spaltenbreiten (Zeichenanzahl ohne Padding)
  COL_ID      = 3;
  COL_DATE    = 19;
  COL_KM      = 8;
  COL_LITER   = 10;
  COL_EUR_L   = 12;
  COL_TOTAL   = 10;
  COL_STATION = 26;

  // Anzahl der Daten-Spalten
  FUELUP_COLS = 7;

  // Berechnung der Gesamtbreite anhand Aussenraendern, Spaltenbreiten, Leerzeichen und Trennern
  FUELUP_TABLE_WIDTH = 2 + (COL_ID + 2) + (COL_DATE + 2) + (COL_KM + 2) + 
                       (COL_LITER + 2) + (COL_EUR_L + 2) + (COL_TOTAL + 2) + 
                       (COL_STATION + 2) + (FUELUP_COLS - 1);

  // Nutzbare Breite fuer Text-Details innerhalb der Box
  FUELUP_DETAIL_WIDTH = FUELUP_TABLE_WIDTH - 4;

implementation

const
  // Unicode Box-Zeichen (Mischung aus doppelten und einfachen Linien)
  U_HORIZ = '═'; U_VERT  = '║'; 
  U_TOP_L = '╔'; U_TOP_R = '╗'; U_T_DWN = '╦';
  U_BOT_L = '╚'; U_BOT_R = '╝'; U_B_UP  = '╩'; 
  U_CROSS = '╬'; U_L_T   = '╠'; U_R_T   = '╣';
  U_SEP_L = '╟'; U_SEP_R = '╢'; U_DASH  = '─';

// Integer-basiertes Fixed-Point-Format (ohne Double/Rundung)
function FmtScaledInt(const V: Int64; const Decimals: Integer; const Suffix: string): string;
var
  AbsV, Scale, IntPart, FracPart: Int64;
  FracStr: string;
  Sign: string;

  // Ganzzahl-Potenz fuer Zehnerpotenzen (ohne Float-Konvertierung)
  function Pow10Int64(const N: Integer): Int64;
  var
    I: Integer;
    R: Int64;
  begin
    R := 1;
    for I := 1 to N do
      R := R * 10;
    Result := R;
  end;

begin
  if Decimals < 0 then
    raise Exception.Create('Decimals darf nicht negativ sein');

  AbsV := Abs(V);
  Scale := Pow10Int64(Decimals);

  IntPart := AbsV div Scale;
  FracPart := AbsV mod Scale;

  FracStr := IntToStr(FracPart);
  while Length(FracStr) < Decimals do
    FracStr := '0' + FracStr;

  if V < 0 then
    Sign := '-'
  else
    Sign := '';

  if Decimals = 0 then
    Result := Sign + IntToStr(IntPart) + ' ' + Suffix
  else
    Result := Sign + IntToStr(IntPart) + ',' + FracStr + ' ' + Suffix;
end;

// Formatiert Cents als EUR mit zwei Nachkommastellen
function FmtEuroFromCents(const V: Int64): string;
begin Result := FmtScaledInt(V, 2, 'EUR'); end;

// Formatiert Milliliter als Liter mit drei Nachkommastellen
function FmtLiterFromMl(const V: Int64): string;
begin Result := FmtScaledInt(V, 3, 'L'); end;

// Formatiert milli-EUR pro Liter mit drei Nachkommastellen
function FmtEurPerLiterFromMilli(const V: Int64): string;
begin Result := FmtScaledInt(V, 3, 'EUR/L'); end;

function FmtBoolYN(const V: Integer): string;
begin
  if V <> 0 then Result := 'Y' else Result := 'N';
end;

// ----------------
// CSV Helper (maschinenlesbar, strikt & simpel)

function CsvTokenStrict(const S: string): string;
begin
  // Strikt: Wir erlauben keinerlei CSV-Sonderzeichen, weil wir bewusst ohne Escaping arbeiten.
  if S = '' then
    raise Exception.Create('CsvTokenStrict: Token darf nicht leer sein');

  if (Pos(',', S) > 0) or (Pos('"', S) > 0) or (Pos(#10, S) > 0) or (Pos(#13, S) > 0) then
    raise Exception.Create('CsvTokenStrict: Token enthaelt unzulaessige CSV-Zeichen');

  Result := S;
end;

function CsvJoin(const Values: array of string): string;
var
  I: Integer;
begin
  Result := '';
  for I := 0 to High(Values) do
  begin
    if I > 0 then
      Result := Result + ',';
    Result := Result + Values[I];
  end;
end;

function CsvJoinInt64(const Values: array of Int64): string;
var
  I: Integer;
begin
  Result := '';
  for I := 0 to High(Values) do
  begin
    if I > 0 then
      Result := Result + ',';
    Result := Result + IntToStr(Values[I]);
  end;
end;

{
  Zentrale Zeichenfunktion fuer horizontale Linien.
  IsSimple = True  -> Erzeugt eine durchgehende Linie (z. B. fuer Separatoren)
  IsSimple = False -> Beruecksichtigt die Spaltenbreiten fuer Kreuzungspunkte
}
procedure DrawLine(const Left, Cross, Right, Char: string; IsSimple: Boolean = False);
var
  s: string;
  function Fill(Len: Integer): string;
  begin 
    // DupeString sorgt dafuer, dass UTF-8 Zeichen korrekt wiederholt werden
    Result := DupeString(Char, Len + 2); 
  end;
begin
  if IsSimple then
    // DupeString statt StringOfChar verwenden
    s := Left + DupeString(Char, FUELUP_TABLE_WIDTH - 2) + Right
  else
    s := Left + Fill(COL_ID) + Cross + Fill(COL_DATE) + Cross + Fill(COL_KM) + Cross + 
         Fill(COL_LITER) + Cross + Fill(COL_EUR_L) + Cross + Fill(COL_TOTAL) + Cross + 
         Fill(COL_STATION) + Right;
  WriteLn(s);
end;

procedure PrintFuelupHeader;
begin
  // Obere Kante
  DrawLine(U_TOP_L, U_T_DWN, U_TOP_R, U_HORIZ);
  // Spaltentitel (Format: %-*s sorgt fuer Linksbundigkeit mit fester Breite)
  WriteLn(Format(U_VERT + ' %-*s ' + U_VERT + ' %-*s ' + U_VERT + ' %-*s ' + U_VERT + 
    ' %-*s ' + U_VERT + ' %-*s ' + U_VERT + ' %-*s ' + U_VERT + ' %-*s ' + U_VERT,
    [COL_ID, 'ID', COL_DATE, 'Datum', COL_KM, 'KM', COL_LITER, 'Liter', 
     COL_EUR_L, 'EUR/L', COL_TOTAL, 'Gesamt', COL_STATION, 'Stations']));
  // Trenner nach Header
  DrawLine(U_L_T, U_CROSS, U_R_T, U_HORIZ);
end;

procedure PrintFuelupFooter(Simple: Boolean = False);
begin
  if Simple then 
    DrawLine(U_BOT_L, '', U_BOT_R, U_HORIZ, True)
  else 
    DrawLine(U_BOT_L, U_B_UP, U_BOT_R, U_HORIZ);
end;

procedure PrintFuelupSeparator;
begin
  // Nutzt duenne Linie (DASH) innerhalb der dicken Box
  DrawLine(U_SEP_L, U_DASH, U_SEP_R, U_DASH, True);
end;

procedure PrintFuelupSeparatorDouble;
begin
  // Nutzt dicke Linie (HORIZ) mit dicken Kreuzungen (fuer Standard-Ansicht)
  DrawLine(U_L_T, U_CROSS, U_R_T, U_HORIZ, False);
end;

procedure PrintFuelupRow(const AId: Integer; const AFueledAt: string; const AOdometerKm, ALitersMl, APriceMilli, ATotalCents: Int64; const AStation: string);
begin
  // Zusammensetzen der Zeile mit Padding-Helfern aus u_table
  WriteLn(U_VERT, ' ', PadL(IntToStr(AId), COL_ID), ' ', 
          U_VERT, ' ', PadR(AFueledAt, COL_DATE), ' ', 
          U_VERT, ' ', PadL(IntToStr(AOdometerKm), COL_KM), ' ', 
          U_VERT, ' ', PadL(FmtLiterFromMl(ALitersMl), COL_LITER), ' ', 
          U_VERT, ' ', PadL(FmtEurPerLiterFromMilli(APriceMilli), COL_EUR_L), ' ', 
          U_VERT, ' ', PadL(FmtEuroFromCents(ATotalCents), COL_TOTAL), ' ', 
          U_VERT, ' ', PadR(AStation, COL_STATION), ' ', U_VERT);
end;

procedure PrintFuelupDetail(const AIsFull: Boolean; const AFuelType, APayment, APump, ANote, AAddress: string);
  // Lokale Hilfsfunktion zum Zeichnen einer Detail-Zeile
  function DetailLine(const S: string): string;
  begin 
    Result := U_VERT + ' ' + PadR(Cut(S, FUELUP_DETAIL_WIDTH), FUELUP_DETAIL_WIDTH) + ' ' + U_VERT; 
  end;
begin
  // Zusammenfassende Info-Zeile
  WriteLn(DetailLine('Full: ' + FmtBoolYN(Ord(AIsFull)) + ' | Fuel: ' + AFuelType + 
                     ' | Pay: ' + APayment + ' | Pump: ' + APump));
  
  // Optional: Notiz nur anzeigen, wenn Text vorhanden
  if Trim(ANote) <> '' then 
    WriteLn(DetailLine('Note: ' + ANote));

  // Adresse
  WriteLn(DetailLine('Addr: ' + AAddress));
end;

end.
